package com.voicestudio.android

import com.voicestudio.android.audio.AudioPipeline
import com.voicestudio.android.domain.ScriptPlanner
import com.voicestudio.android.domain.VoiceStudioCatalog
import com.voicestudio.android.engine.KokoroOnnxEngine
import com.voicestudio.android.engine.MultilingualG2pPhonemizer
import com.voicestudio.android.engine.OpenVoiceCloningEngine
import com.voicestudio.android.engine.TeluguVitsOnnxEngine
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

class VoiceStudioEngineUnitTest {

    @Test
    fun testPauseTagParsingAndWordCount() {
        val raw = "Welcome back! [pause 1.5] Today we talk about [pause] something new."
        val segments = ScriptPlanner.parseScript(raw)
        assertEquals(4, segments.size)
        assertEquals(10, ScriptPlanner.countWordsFast(raw))
    }

    @Test
    fun testDeterministicSynthesisPlanMatchesPacingStyle() {
        val script = "First sentence here? Second sentence here!\n\nNew paragraph sentence."
        val style = VoiceStudioCatalog.STYLES.first { it.id == "conversational" }
        val plan1 = ScriptPlanner.buildSynthesisPlan(script, 1.0f, style)
        val plan2 = ScriptPlanner.buildSynthesisPlan(script, 1.0f, style)
        assertEquals(plan1, plan2) // Seed 7 must guarantee deterministic output
    }

    @Test
    fun testVoiceLibraryCountAndBlendNamesMatchExtension() {
        val (library, groups) = VoiceStudioCatalog.buildFullVoiceLibrary()
        // 255 original Kokoro entries + 3 Telugu entries = 258
        assertEquals(258, library.size)
        assertEquals(8, groups.size)
        val firstFemaleBlend = library.first { it.group == "en-us" && it.gender == "Female" && it.kind == "blend" }
        assertEquals("Yara", firstFemaleBlend.name)
        val firstMaleBlend = library.first { it.group == "en-us" && it.gender == "Male" && it.kind == "blend" }
        assertEquals("Stan", firstMaleBlend.name)
    }

    @Test
    fun testKokoroIpaTokenizationWithBosEosPadding() {
        val sampleIpa = "hˌaʊ kʊd aɪ nˈoʊ? ɪts ɐn ʌnˈænsɚɹəbəl kwˈɛstʃən."
        val padded = KokoroOnnxEngine.tokenizeIpa(sampleIpa)
        assertEquals(0L, padded.first()) // BOS
        assertEquals(0L, padded.last())  // EOS
        assertEquals(50, padded.size)    // 48 content tokens + 2 pad tokens
    }

    @Test
    fun testTeluguVitsTokenizerAndFallbackSynthesis() {
        val teluguSentence = "నమస్కారం, వాయిస్ స్టూడియోకి స్వాగతం."
        val tokens = TeluguVitsOnnxEngine.tokenizeTeluguWithBlanks(teluguSentence)
        assertEquals(0L, tokens.first())
        assertEquals(0L, tokens.last())
        assertTrue(tokens.size > 15)

        val audio = TeluguVitsOnnxEngine.synthesizeTeluguKlattFallback(teluguSentence, "tf_padma", 1.0f)
        assertTrue(audio.size > AudioPipeline.SAMPLE_RATE)
    }

    @Test
    fun testOpenVoiceStftAndSpeakerEmbeddingExtraction() {
        // 1.5 seconds of 22,050 Hz harmonic test signal
        val samples22k = FloatArray((22050 * 1.5).toInt()) { i ->
            (0.5 * sin(2.0 * PI * 180.0 * i / 22050.0)).toFloat()
        }
        val spec = OpenVoiceCloningEngine.computeOpenVoiceSpectrogram(samples22k)
        assertTrue(spec.isNotEmpty())
        assertEquals(513, spec[0].size)

        val emb = OpenVoiceCloningEngine.extractDspAcousticEmbedding(spec)
        assertEquals(256, emb.size)
    }

    @Test
    fun testAccentAdaptationPhonemizerTransforms() {
        val phonemizer = MultilingualG2pPhonemizer()
        val usIpa = phonemizer.phonemize("Today we talk about everything", "en-us")
        val ukIpa = phonemizer.phonemize("Today we talk about everything", "en-gb")
        val auIpa = phonemizer.phonemize("Today we talk about everything", "en-au")
        val inIpa = phonemizer.phonemize("Today we talk about everything", "en-in")
        assertTrue(usIpa.isNotEmpty() && ukIpa.isNotEmpty() && auIpa.isNotEmpty() && inIpa.isNotEmpty())
    }

    @Test
    fun testWavEncodingPeakNormalizationAnd1200BarExtraction() {
        val raw = FloatArray(AudioPipeline.SAMPLE_RATE) { i ->
            (sin(2.0 * PI * 440.0 * i / AudioPipeline.SAMPLE_RATE) * 1.25).toFloat()
        }
        AudioPipeline.normalizePeakInPlace(raw, 0.98f)
        val maxPeak = raw.maxOf { abs(it) }
        assertEquals(0.98f, maxPeak, 1e-4f)

        val wavBytes = AudioPipeline.encodePcm16WavBytes(raw)
        val peaks = AudioPipeline.extractWavPeaksFast(wavBytes, 1200)
        assertEquals(1200, peaks.size)
        assertTrue(peaks.maxOrNull()!! > 0.90f)
    }
}
