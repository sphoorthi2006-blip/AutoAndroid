package com.voicestudio.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.voicestudio.android.data.model.PersonalVoiceProfile
import com.voicestudio.android.data.model.TargetAccent
import com.voicestudio.android.ui.theme.StudioColors
import com.voicestudio.android.viewmodel.StudioUiState

/**
 * My Voice (Zero-Shot Reference-Audio Voice Cloning) & Cross-Accent Adaptation Screen:
 * 1. Record reference audio via phone microphone (`AudioRecord` @ 24,000 Hz) with live meter
 * 2. Import an existing WAV voice recording from device storage
 * 3. Preview and trim start/end points with a `RangeSlider`
 * 4. Confirm ownership/permission consent and extract a 256-float speaker tone embedding (`tone_extract.onnx`)
 * 5. Manage saved local voice profiles (Select for generation, Rename, Delete)
 * 6. Select Target Accent (American, British, Australian, Indian English) for cross-accent synthesis
 */
@Composable
fun MyVoiceAndAccentScreen(
    state: StudioUiState,
    onStartRecordingClick: () -> Unit,
    onStopRecordingClick: () -> Unit,
    onImportWavClick: () -> Unit,
    onTrimRangeChange: (Float, Float) -> Unit,
    onPreviewTrimmedClick: () -> Unit,
    onProfileNameChange: (String) -> Unit,
    onConsentCheckedChange: (Boolean) -> Unit,
    onSaveProfileClick: () -> Unit,
    onSelectProfile: (String, Boolean) -> Unit,
    onRenameProfile: (String, String) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onSelectTargetAccent: (TargetAccent) -> Unit
) {
    val scrollState = rememberScrollState()
    var renameTarget by remember { mutableStateOf<PersonalVoiceProfile?>(null) }
    var renameText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Section 1: Record or Import Reference Voice
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Text(
                text = "MY VOICE — ZERO-SHOT REFERENCE VOICE CLONING",
                style = MaterialTheme.typography.labelSmall,
                color = StudioColors.AccentTeal
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Record 5–15 seconds of clear speech in a quiet room or import a WAV recording. OpenVoice V2 extracts a 256-dimensional vocal timbre embedding stored 100% locally on your phone.",
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (state.isRecordingMic) {
                    Button(
                        onClick = onStopRecordingClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioColors.DangerRed)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Stop Recording", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = onStartRecordingClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentViolet)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Record My Voice", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                OutlinedButton(
                    onClick = onImportWavClick,
                    enabled = !state.isRecordingMic,
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.FileUpload, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Import WAV")
                }
            }

            if (state.isRecordingMic) {
                Spacer(modifier = Modifier.height(10.dp))
                Text("Live microphone level:", style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { state.micLiveAmplitude.coerceIn(0.05f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = StudioColors.AccentTeal,
                    trackColor = StudioColors.PanelElevated
                )
            }

            // Trim & Save Candidate Card
            if (state.candidateDurationSec >= 1.0f && !state.isRecordingMic) {
                Spacer(modifier = Modifier.height(14.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(StudioColors.PanelElevated)
                        .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = String.format(
                                "Trim Clip: %.1fs – %.1fs (%.1fs selected)",
                                state.candidateTrimStartSec,
                                state.candidateTrimEndSec,
                                state.candidateTrimEndSec - state.candidateTrimStartSec
                            ),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        OutlinedButton(
                            onClick = onPreviewTrimmedClick,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Preview Clip", fontSize = 12.sp)
                        }
                    }

                    RangeSlider(
                        value = state.candidateTrimStartSec..state.candidateTrimEndSec,
                        onValueChange = { range -> onTrimRangeChange(range.start, range.endInclusive) },
                        valueRange = 0f..state.candidateDurationSec.coerceAtLeast(1f)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = state.candidateProfileName,
                        onValueChange = onProfileNameChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Voice profile name (e.g., My Studio Voice)") },
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onConsentCheckedChange(!state.candidateConsentChecked) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = state.candidateConsentChecked,
                            onCheckedChange = onConsentCheckedChange,
                            colors = CheckboxDefaults.colors(checkedColor = StudioColors.AccentTeal)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "I confirm that this is my own voice or a voice I have explicit permission to clone locally.",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioColors.TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = onSaveProfileClick,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(9.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentTeal)
                    ) {
                        Text(
                            text = "Create Personal AI Voice Profile",
                            color = Color(0xFF071318),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Section 2: Accent Adaptation Selector
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Text(
                text = "ACCENT ADAPTATION (FOR MY VOICE PROFILES)",
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Synthesizes base speech with regional pronunciation & cadence rules, then maps vocal timbre to your personal voice profile via OpenVoice V2 tone color conversion.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(modifier = Modifier.height(10.dp))

            TargetAccent.entries.forEach { accent ->
                val isSelected = state.selectedTargetAccent == accent
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) StudioColors.PresetActiveSurface else StudioColors.PanelElevated)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) StudioColors.AccentTeal else StudioColors.BorderLine,
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectTargetAccent(accent) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = accent.flagEmoji, fontSize = 22.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = accent.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (isSelected) StudioColors.AccentTeal else StudioColors.TextPrimary
                        )
                        Text(
                            text = accent.description,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.5.sp
                        )
                    }
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Selected",
                            tint = StudioColors.AccentTeal
                        )
                    }
                }
            }
        }

        // Section 3: Saved Personal Voice Profiles
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Text(
                text = "SAVED PERSONAL VOICE PROFILES (${state.personalVoices.size})",
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (state.personalVoices.isEmpty()) {
                Text(
                    text = "No personal voice profiles saved yet. Record or import a voice clip above to create your first profile.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                state.personalVoices.forEach { profile ->
                    val isActive = state.usePersonalClonedVoice && state.selectedPersonalVoiceId == profile.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isActive) StudioColors.PresetActiveSurface else StudioColors.PanelElevated)
                            .border(
                                width = 1.dp,
                                color = if (isActive) StudioColors.AccentTeal else StudioColors.BorderLine,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isActive) StudioColors.AccentTeal else StudioColors.TextPrimary
                            )
                            Text(
                                text = String.format("Ref clip: %.1fs • 256-D Embedding stored locally", profile.referenceDurationSec),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(
                                checked = isActive,
                                onCheckedChange = { enabled -> onSelectProfile(profile.id, enabled) }
                            )
                            IconButton(onClick = {
                                renameTarget = profile
                                renameText = profile.name
                            }) {
                                Icon(Icons.Default.Edit, contentDescription = "Rename", tint = StudioColors.TextMuted)
                            }
                            IconButton(onClick = { onDeleteProfile(profile.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StudioColors.DangerRed)
                            }
                        }
                    }
                }
            }
        }
    }

    if (renameTarget != null) {
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Voice Profile") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true,
                    label = { Text("Profile Name") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    renameTarget?.let { onRenameProfile(it.id, renameText) }
                    renameTarget = null
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
