package com.voicestudio.android.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.voicestudio.android.audio.AudioPipeline
import com.voicestudio.android.audio.StudioAudioPlayer
import com.voicestudio.android.audio.VoiceMicrophoneRecorder
import com.voicestudio.android.data.local.SavedStudioPrefs
import com.voicestudio.android.data.local.StudioPreferencesStore
import com.voicestudio.android.data.model.ConversationStyle
import com.voicestudio.android.data.model.EnginePhase
import com.voicestudio.android.data.model.LanguageGroup
import com.voicestudio.android.data.model.ModelPackId
import com.voicestudio.android.data.model.ModelPackStatus
import com.voicestudio.android.data.model.PersonalVoiceProfile
import com.voicestudio.android.data.model.SavedProjectItem
import com.voicestudio.android.data.model.TargetAccent
import com.voicestudio.android.data.model.VoiceLibraryEntry
import com.voicestudio.android.data.model.VoicePreset
import com.voicestudio.android.data.repository.ModelStorageManager
import com.voicestudio.android.data.repository.VoiceSynthesisCoordinator
import com.voicestudio.android.domain.ScriptPlanner
import com.voicestudio.android.domain.VoiceStudioCatalog
import com.voicestudio.android.service.GenerationForegroundService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class StudioUiState(
    val enginePhase: EnginePhase = EnginePhase.STARTING,
    val engineBadgeText: String = "Checking offline models...",
    val statusMessage: String = "Ready. Tap a preset to hear it, or paste a script and press Generate.",
    val isStatusError: Boolean = false,
    val isBusyGenerating: Boolean = false,
    val progressPct: Int = 0,

    // Script editor state
    val script: String = "",
    val wordCount: Int = 0,
    val estimatedDurationSec: Int = 0,

    // Voice library & filtering
    val groups: List<LanguageGroup> = emptyList(),
    val fullLibrary: List<VoiceLibraryEntry> = emptyList(),
    val filteredLibrary: List<VoiceLibraryEntry> = emptyList(),
    val selectedGroupId: String = "en-us",
    val selectedGender: String = "all",
    val selectedLibraryId: String = "en-us:f:af_heart",
    val favorites: Set<String> = emptySet(),
    val libraryNote: String = "",

    // Main & blend voice, speed, style, preset
    val baseVoices: List<String> = VoiceStudioCatalog.KOKORO_BASE_VOICES,
    val mainVoice: String = "af_heart",
    val blendVoice: String = "",
    val blendPercent: Int = 0,
    val speedPercent: Int = 100,
    val styles: List<ConversationStyle> = VoiceStudioCatalog.STYLES,
    val selectedStyleId: String = "conversational",
    val presets: List<VoicePreset> = VoiceStudioCatalog.PRESETS,
    val activePresetIndex: Int = -1,

    // My Voice (Zero-Shot Reference Audio Voice Cloning) & Accent Adaptation
    val personalVoices: List<PersonalVoiceProfile> = emptyList(),
    val usePersonalClonedVoice: Boolean = false,
    val selectedPersonalVoiceId: String = "",
    val selectedTargetAccent: TargetAccent = TargetAccent.AMERICAN_ENGLISH,
    val isRecordingMic: Boolean = false,
    val micLiveAmplitude: Float = 0f,
    val recordedCandidateSamples: FloatArray = FloatArray(0),
    val recordedCandidatePeaks: FloatArray = FloatArray(120),
    val candidateDurationSec: Float = 0f,
    val candidateTrimStartSec: Float = 0f,
    val candidateTrimEndSec: Float = 0f,
    val candidateProfileName: String = "",
    val candidateConsentChecked: Boolean = false,

    // Audio player & 1,200-bar waveform state
    val hasLoadedAudio: Boolean = false,
    val isPlayingAudio: Boolean = false,
    val currentPlayheadSec: Float = 0f,
    val totalAudioDurationSec: Float = 0f,
    val waveformPeaks: FloatArray = FloatArray(AudioPipeline.DEFAULT_PEAK_BARS),
    val currentWavFile: File? = null,
    val lastGeneratedKind: String = "voiceover",

    // Projects & History
    val savedProjects: List<SavedProjectItem> = emptyList(),

    // Model packs & storage
    val modelPacks: List<ModelPackStatus> = emptyList(),
    val availableStorageMb: String = ""
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val prefsStore = StudioPreferencesStore(context)
    private val modelStorage = ModelStorageManager(context)
    private val coordinator = VoiceSynthesisCoordinator(context, modelStorage)
    private val audioPlayer = StudioAudioPlayer(context)
    private val micRecorder = VoiceMicrophoneRecorder()

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private var activeGenerationJob: Job? = null
    private var saveDebounceJob: Job? = null
    private var playheadTickerJob: Job? = null
    private var lastSynthesisSamples: FloatArray = FloatArray(0)

    init {
        audioPlayer.onCompletion = {
            _uiState.update {
                it.copy(
                    isPlayingAudio = false,
                    currentPlayheadSec = it.totalAudioDurationSec
                )
            }
            playheadTickerJob?.cancel()
        }
        bootstrapStudio()
    }

    private fun bootstrapStudio() {
        viewModelScope.launch {
            val (library, groups) = VoiceStudioCatalog.buildFullVoiceLibrary()
            val saved = prefsStore.prefsFlow.first()
            val personalProfiles = withContext(Dispatchers.IO) { prefsStore.loadPersonalVoiceProfiles() }
            val projects = withContext(Dispatchers.IO) { prefsStore.loadSavedProjects() }
            val wordCnt = ScriptPlanner.countWordsFast(saved.script)
            val estSecs = ScriptPlanner.estimateDurationSeconds(wordCnt, saved.speedPercent / 100f)
            val accent = TargetAccent.entries.firstOrNull { it.id == saved.selectedTargetAccentId }
                ?: TargetAccent.AMERICAN_ENGLISH

            _uiState.update { state ->
                state.copy(
                    groups = groups,
                    fullLibrary = library,
                    script = saved.script,
                    wordCount = wordCnt,
                    estimatedDurationSec = estSecs,
                    mainVoice = saved.voice,
                    blendVoice = saved.blendVoice,
                    blendPercent = saved.blendPercent,
                    speedPercent = saved.speedPercent,
                    selectedStyleId = saved.styleId,
                    activePresetIndex = saved.activePresetIndex,
                    selectedGroupId = saved.libGroup,
                    selectedGender = saved.libGender,
                    selectedLibraryId = saved.libSel,
                    favorites = saved.favs.toSet(),
                    personalVoices = personalProfiles,
                    selectedPersonalVoiceId = saved.selectedClonedVoiceId.ifEmpty { personalProfiles.firstOrNull()?.id.orEmpty() },
                    usePersonalClonedVoice = saved.selectedClonedVoiceId.isNotEmpty() && personalProfiles.any { it.id == saved.selectedClonedVoiceId },
                    selectedTargetAccent = accent,
                    savedProjects = projects
                )
            }
            rebuildFilteredLibrary(keepSelection = true)
            refreshModelPackStatus()
        }
    }

    fun refreshModelPackStatus() {
        viewModelScope.launch {
            val packs = withContext(Dispatchers.IO) { modelStorage.getAllPackStatuses() }
            val freeMb = modelStorage.formatMb(modelStorage.getAvailableStorageBytes())
            val kokoroInstalled = modelStorage.isKokoroReady()

            if (kokoroInstalled) {
                _uiState.update {
                    it.copy(
                        enginePhase = EnginePhase.LOADING,
                        engineBadgeText = "Loading voices...",
                        modelPacks = packs,
                        availableStorageMb = freeMb
                    )
                }
                coordinator.initializeInstalledModels { msg ->
                    _uiState.update { it.copy(statusMessage = msg) }
                }
                _uiState.update {
                    it.copy(
                        enginePhase = EnginePhase.READY,
                        engineBadgeText = "Engine ready (Offline)",
                        statusMessage = "Ready. Tap a preset to hear it, or paste a script and press Generate.",
                        isStatusError = false,
                        modelPacks = modelStorage.getAllPackStatuses(),
                        availableStorageMb = freeMb
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        enginePhase = EnginePhase.MISSING_MODELS,
                        engineBadgeText = "Built-in Synth (Models optional)",
                        statusMessage = "Offline acoustic engine active. Download or import Kokoro-82M in Model Management for full neural voices.",
                        isStatusError = false,
                        modelPacks = packs,
                        availableStorageMb = freeMb
                    )
                }
            }
        }
    }

    // ---------------- Script & Editor Actions ----------------

    fun onScriptChanged(newScript: String) {
        val words = ScriptPlanner.countWordsFast(newScript)
        val speedMult = _uiState.value.speedPercent / 100f
        val estSec = ScriptPlanner.estimateDurationSeconds(words, speedMult)
        _uiState.update {
            it.copy(
                script = newScript,
                wordCount = words,
                estimatedDurationSec = estSec
            )
        }
        schedulePrefsSave()
    }

    fun insertPauseTagAtEndOrCursor(pauseSec: String = "1") {
        val tag = "[pause $pauseSec]"
        val current = _uiState.value.script
        val updated = if (current.isEmpty() || current.endsWith(" ")) "$current$tag " else "$current $tag "
        onScriptChanged(updated)
    }

    fun clearScript() {
        onScriptChanged("")
    }

    fun loadTeluguSampleSentence(sentence: String) {
        _uiState.update {
            it.copy(
                selectedGroupId = "te",
                mainVoice = "tf_padma",
                blendVoice = "",
                blendPercent = 0,
                usePersonalClonedVoice = false
            )
        }
        rebuildFilteredLibrary(keepSelection = false)
        onScriptChanged(sentence)
    }

    fun importTxtFile(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalArgumentException("Unable to read .txt file")
                withContext(Dispatchers.Main) {
                    onScriptChanged(text)
                    setStatus("Loaded .txt script (${ScriptPlanner.countWordsFast(text)} words).", isError = false)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    setStatus("Could not load .txt file: ${e.message}", isError = true)
                }
            }
        }
    }

    // ---------------- Voice Library, Presets & Custom Mix ----------------

    fun selectLanguageGroup(groupId: String) {
        _uiState.update { it.copy(selectedGroupId = groupId) }
        rebuildFilteredLibrary(keepSelection = false)
        schedulePrefsSave()
    }

    fun selectGenderFilter(gender: String) {
        _uiState.update { it.copy(selectedGender = gender) }
        rebuildFilteredLibrary(keepSelection = true)
        schedulePrefsSave()
    }

    private fun rebuildFilteredLibrary(keepSelection: Boolean) {
        val st = _uiState.value
        val gid = st.selectedGroupId
        val gen = st.selectedGender
        val source = if (gid == "fav") {
            st.fullLibrary.filter { it.id in st.favorites && (gen == "all" || it.gender == gen) }
                .sortedBy { it.kind == "single" }
        } else {
            st.fullLibrary.filter { it.group == gid && (gen == "all" || it.gender == gen) }
                .sortedBy { it.kind == "single" }
        }

        val note = when {
            gid == "fav" -> if (source.isNotEmpty()) "" else "No favorites yet. Pick a voice and tap Favorite."
            gid == "te" -> "Telugu voices speak native Telugu script (తెలుగు). Type or tap a Telugu sample sentence to test."
            gid == "hi" -> "Hindi voices speak Hindi (write your script in Devanagari). Use My Voice + Indian English accent for Indian-accent English."
            gid.startsWith("en") -> "Kokoro has American and British base voices. For Australian or Indian English, use the Accent Adaptation tab."
            else -> "Write your script in this language."
        }

        val currentSel = st.selectedLibraryId
        val nextSelEntry = if (keepSelection && source.any { it.id == currentSel }) {
            source.first { it.id == currentSel }
        } else {
            source.firstOrNull()
        }

        _uiState.update {
            it.copy(
                filteredLibrary = source,
                libraryNote = note,
                selectedLibraryId = nextSelEntry?.id.orEmpty(),
                mainVoice = nextSelEntry?.voice ?: it.mainVoice,
                blendVoice = nextSelEntry?.blendVoice.orEmpty(),
                blendPercent = ((nextSelEntry?.blend ?: 0f) * 100f).roundToInt()
            )
        }
    }

    fun selectLibraryVoice(libraryId: String, autoAudition: Boolean) {
        val entry = _uiState.value.fullLibrary.firstOrNull { it.id == libraryId } ?: return
        _uiState.update {
            it.copy(
                selectedLibraryId = entry.id,
                mainVoice = entry.voice,
                blendVoice = entry.blendVoice.orEmpty(),
                blendPercent = (entry.blend * 100f).roundToInt(),
                activePresetIndex = -1,
                usePersonalClonedVoice = false
            )
        }
        schedulePrefsSave()
        if (autoAudition) {
            auditionCurrentLibraryVoice()
        }
    }

    fun stepLibraryVoice(delta: Int) {
        val list = _uiState.value.filteredLibrary
        if (list.isEmpty()) return
        val curIdx = list.indexOfFirst { it.id == _uiState.value.selectedLibraryId }.coerceAtLeast(0)
        val nextIdx = (curIdx + delta + list.size) % list.size
        selectLibraryVoice(list[nextIdx].id, autoAudition = true)
    }

    fun shuffleLibraryVoice() {
        val list = _uiState.value.filteredLibrary
        if (list.isEmpty()) return
        val randomEntry = list.random()
        selectLibraryVoice(randomEntry.id, autoAudition = true)
    }

    fun toggleFavoriteCurrentVoice() {
        val libId = _uiState.value.selectedLibraryId
        if (libId.isEmpty()) return
        val updatedFavs = _uiState.value.favorites.toMutableSet()
        if (!updatedFavs.add(libId)) {
            updatedFavs.remove(libId)
        }
        _uiState.update { it.copy(favorites = updatedFavs) }
        if (_uiState.value.selectedGroupId == "fav") {
            rebuildFilteredLibrary(keepSelection = true)
        }
        schedulePrefsSave()
    }

    fun applyPreset(preset: VoicePreset) {
        _uiState.update {
            it.copy(
                mainVoice = preset.voice,
                blendVoice = preset.blendVoice,
                blendPercent = (preset.blend * 100f).roundToInt(),
                speedPercent = (preset.speed * 100f).roundToInt(),
                selectedStyleId = preset.style,
                activePresetIndex = preset.index,
                usePersonalClonedVoice = false,
                estimatedDurationSec = ScriptPlanner.estimateDurationSeconds(it.wordCount, preset.speed)
            )
        }
        schedulePrefsSave()
        runSynthesis(isPreview = true)
    }

    fun setMainVoiceCustom(voiceId: String) {
        _uiState.update { it.copy(mainVoice = voiceId, activePresetIndex = -1, usePersonalClonedVoice = false) }
        schedulePrefsSave()
    }

    fun setBlendVoiceCustom(voiceId: String) {
        _uiState.update { it.copy(blendVoice = voiceId, activePresetIndex = -1, usePersonalClonedVoice = false) }
        schedulePrefsSave()
    }

    fun setBlendPercentCustom(pct: Int) {
        _uiState.update { it.copy(blendPercent = pct.coerceIn(0, 100), activePresetIndex = -1) }
        schedulePrefsSave()
    }

    fun setSpeedPercent(pct: Int) {
        val clamped = pct.coerceIn(60, 150)
        _uiState.update {
            it.copy(
                speedPercent = clamped,
                activePresetIndex = -1,
                estimatedDurationSec = ScriptPlanner.estimateDurationSeconds(it.wordCount, clamped / 100f)
            )
        }
        schedulePrefsSave()
    }

    fun setConversationStyle(styleId: String) {
        _uiState.update { it.copy(selectedStyleId = styleId, activePresetIndex = -1) }
        schedulePrefsSave()
    }

    fun auditionSingleBaseVoice(voiceId: String) {
        if (voiceId.isBlank()) {
            setStatus("Pick a blend voice first.", isError = true)
            return
        }
        val sample = VoiceStudioCatalog.sampleTextForVoice(voiceId)
        runSynthesis(
            isPreview = true,
            overrideText = sample,
            overrideVoice = voiceId,
            overrideBlendVoice = null,
            overrideBlendRatio = 0f
        )
    }

    fun auditionCurrentLibraryVoice() {
        val st = _uiState.value
        val overrideTxt = if (st.script.isBlank()) VoiceStudioCatalog.sampleTextForVoice(st.mainVoice) else null
        runSynthesis(isPreview = true, overrideText = overrideTxt)
    }

    // ---------------- My Voice (Reference Audio Cloning) & Accent Adaptation ----------------

    fun startMicRecording() {
        try {
            micRecorder.startRecording { amp ->
                _uiState.update { it.copy(micLiveAmplitude = amp) }
            }
            _uiState.update {
                it.copy(
                    isRecordingMic = true,
                    statusMessage = "Recording reference voice... Speak naturally for 5 to 15 seconds."
                )
            }
        } catch (e: Exception) {
            setStatus("Microphone error: ${e.message}", isError = true)
        }
    }

    fun stopMicRecording() {
        val samples = micRecorder.stopRecording()
        val dur = samples.size.toFloat() / AudioPipeline.SAMPLE_RATE
        val peaks = AudioPipeline.extractPeaksFromSamples(samples, 120)
        _uiState.update {
            it.copy(
                isRecordingMic = false,
                micLiveAmplitude = 0f,
                recordedCandidateSamples = samples,
                recordedCandidatePeaks = peaks,
                candidateDurationSec = dur,
                candidateTrimStartSec = 0f,
                candidateTrimEndSec = dur,
                statusMessage = String.format("Recorded %.1fs reference audio. Preview, trim, and save your voice profile.", dur)
            )
        }
    }

    fun importReferenceVoiceUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val input = context.contentResolver.openInputStream(uri)
                    ?: throw IllegalArgumentException("Could not open audio file")
                val samples = AudioPipeline.decodeWavToMonoFloat24k(input)
                if (samples.size < AudioPipeline.SAMPLE_RATE) {
                    throw IllegalArgumentException("Please select a WAV recording at least 1 second long.")
                }
                val dur = samples.size.toFloat() / AudioPipeline.SAMPLE_RATE
                val peaks = AudioPipeline.extractPeaksFromSamples(samples, 120)
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            recordedCandidateSamples = samples,
                            recordedCandidatePeaks = peaks,
                            candidateDurationSec = dur,
                            candidateTrimStartSec = 0f,
                            candidateTrimEndSec = dur,
                            statusMessage = String.format("Imported %.1fs reference audio.", dur),
                            isStatusError = false
                        )
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    setStatus("Import failed: ${e.message}", isError = true)
                }
            }
        }
    }

    fun updateCandidateTrim(startSec: Float, endSec: Float) {
        val maxDur = _uiState.value.candidateDurationSec
        val s = startSec.coerceIn(0f, (maxDur - 0.5f).coerceAtLeast(0f))
        val e = endSec.coerceIn(s + 0.5f, maxDur.coerceAtLeast(0.5f))
        _uiState.update { it.copy(candidateTrimStartSec = s, candidateTrimEndSec = e) }
    }

    fun updateCandidateProfileName(name: String) {
        _uiState.update { it.copy(candidateProfileName = name) }
    }

    fun updateCandidateConsent(checked: Boolean) {
        _uiState.update { it.copy(candidateConsentChecked = checked) }
    }

    fun previewTrimmedCandidateRecording() {
        val st = _uiState.value
        if (st.recordedCandidateSamples.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val trimmed = AudioPipeline.trimAudioSamples(
                st.recordedCandidateSamples,
                st.candidateTrimStartSec,
                st.candidateTrimEndSec
            )
            val tmpFile = File(context.cacheDir, "previews/candidate_trim_preview.wav")
            AudioPipeline.writeWavFile(tmpFile, trimmed)
            val peaks = AudioPipeline.extractPeaksFromSamples(trimmed, AudioPipeline.DEFAULT_PEAK_BARS)
            withContext(Dispatchers.Main) {
                loadAndPlayFile(tmpFile, peaks, trimmed)
            }
        }
    }

    fun savePersonalVoiceProfile() {
        val st = _uiState.value
        if (st.recordedCandidateSamples.isEmpty()) {
            setStatus("Record or import a voice sample first.", isError = true)
            return
        }
        if (!st.candidateConsentChecked) {
            setStatus("Please confirm you own or have permission to clone this voice.", isError = true)
            return
        }
        viewModelScope.launch {
            try {
                setStatus("Extracting 256-D speaker tone embedding offline...", isError = false)
                val trimmed = AudioPipeline.trimAudioSamples(
                    st.recordedCandidateSamples,
                    st.candidateTrimStartSec,
                    st.candidateTrimEndSec
                )
                val profile = coordinator.createPersonalVoiceProfile(
                    name = st.candidateProfileName.ifBlank { "My Voice ${st.personalVoices.size + 1}" },
                    trimmedSamples24k = trimmed,
                    trimStartSec = st.candidateTrimStartSec,
                    trimEndSec = st.candidateTrimEndSec,
                    preferredAccent = st.selectedTargetAccent,
                    consentConfirmed = st.candidateConsentChecked
                )
                val updated = listOf(profile) + st.personalVoices
                withContext(Dispatchers.IO) { prefsStore.savePersonalVoiceProfiles(updated) }
                _uiState.update {
                    it.copy(
                        personalVoices = updated,
                        selectedPersonalVoiceId = profile.id,
                        usePersonalClonedVoice = true,
                        candidateProfileName = "",
                        statusMessage = "Saved personal voice profile '${profile.name}'. Active for generation.",
                        isStatusError = false
                    )
                }
                schedulePrefsSave()
            } catch (e: Exception) {
                setStatus(e.message ?: "Failed to create voice profile", isError = true)
            }
        }
    }

    fun selectPersonalVoiceForGeneration(profileId: String, enabled: Boolean) {
        _uiState.update {
            it.copy(
                selectedPersonalVoiceId = profileId,
                usePersonalClonedVoice = enabled
            )
        }
        schedulePrefsSave()
    }

    fun renamePersonalVoiceProfile(profileId: String, newName: String) {
        val clean = newName.trim()
        if (clean.isEmpty()) return
        val updated = _uiState.value.personalVoices.map {
            if (it.id == profileId) it.copy(name = clean) else it
        }
        _uiState.update { it.copy(personalVoices = updated) }
        viewModelScope.launch(Dispatchers.IO) { prefsStore.savePersonalVoiceProfiles(updated) }
    }

    fun deletePersonalVoiceProfile(profileId: String) {
        val target = _uiState.value.personalVoices.firstOrNull { it.id == profileId }
        target?.let {
            File(it.referenceWavPath).delete()
            File(it.toneEmbeddingPath).delete()
        }
        val updated = _uiState.value.personalVoices.filterNot { it.id == profileId }
        _uiState.update {
            it.copy(
                personalVoices = updated,
                selectedPersonalVoiceId = if (it.selectedPersonalVoiceId == profileId) updated.firstOrNull()?.id.orEmpty() else it.selectedPersonalVoiceId,
                usePersonalClonedVoice = if (it.selectedPersonalVoiceId == profileId) false else it.usePersonalClonedVoice
            )
        }
        viewModelScope.launch(Dispatchers.IO) { prefsStore.savePersonalVoiceProfiles(updated) }
    }

    fun selectTargetAccent(accent: TargetAccent) {
        _uiState.update { it.copy(selectedTargetAccent = accent) }
        schedulePrefsSave()
    }

    // ---------------- Core Generation, Cancellation, Playback & Export ----------------

    fun runSynthesis(
        isPreview: Boolean,
        overrideText: String? = null,
        overrideVoice: String? = null,
        overrideBlendVoice: String? = null,
        overrideBlendRatio: Float? = null
    ) {
        if (_uiState.value.isBusyGenerating) return
        val st = _uiState.value
        val voiceToUse = overrideVoice ?: st.mainVoice
        val defaultSample = VoiceStudioCatalog.sampleTextForVoice(voiceToUse)
        val textToSynthesize = overrideText ?: if (isPreview) {
            ScriptPlanner.extractPreviewText(st.script, defaultSample = defaultSample)
        } else {
            st.script.trim()
        }

        if (textToSynthesize.isBlank()) {
            setStatus("The script is empty. Paste or type your script first.", isError = true)
            return
        }

        val styleObj = st.styles.firstOrNull { it.id == st.selectedStyleId } ?: VoiceStudioCatalog.STYLES.first()
        val clonedProfile = if (st.usePersonalClonedVoice && overrideVoice == null) {
            st.personalVoices.firstOrNull { it.id == st.selectedPersonalVoiceId }
        } else null

        pauseAudio()
        _uiState.update {
            it.copy(
                isBusyGenerating = true,
                progressPct = 0,
                statusMessage = if (isPreview) "Making preview..." else "Generating voiceover...",
                isStatusError = false
            )
        }
        if (!isPreview) {
            GenerationForegroundService.startOrUpdate(context, "Generating voiceover...", 0)
        }

        activeGenerationJob = viewModelScope.launch {
            try {
                val output = coordinator.synthesizeScript(
                    text = textToSynthesize,
                    voice = voiceToUse,
                    blendVoice = overrideBlendVoice ?: st.blendVoice.ifBlank { null },
                    blendRatio = overrideBlendRatio ?: (st.blendPercent / 100f),
                    speed = st.speedPercent / 100f,
                    style = styleObj,
                    isPreview = isPreview,
                    clonedProfile = clonedProfile,
                    targetAccent = if (clonedProfile != null) st.selectedTargetAccent else null
                ) { msg, pct ->
                    val prefix = if (isPreview) "Preview: " else ""
                    _uiState.update { it.copy(statusMessage = prefix + msg, progressPct = pct) }
                    if (!isPreview) {
                        GenerationForegroundService.startOrUpdate(context, msg, pct)
                    }
                }

                lastSynthesisSamples = output.samples
                loadAndPlayFile(output.wavFile, output.peaks, output.samples)
                val kindLabel = if (isPreview) "Preview ready" else "Voiceover ready"
                _uiState.update {
                    it.copy(
                        lastGeneratedKind = if (isPreview) "preview" else "voiceover",
                        progressPct = 100,
                        statusMessage = "$kindLabel (${formatDuration(output.durationSec)}) • ${output.engineSummaryNote}"
                    )
                }

                if (!isPreview) {
                    val voiceName = clonedProfile?.let { "My Voice: ${it.name}" }
                        ?: VoiceStudioCatalog.friendlyVoiceLabel(voiceToUse)
                    val project = SavedProjectItem(
                        id = output.jobId,
                        title = textToSynthesize.take(42).replace('\n', ' '),
                        scriptSnippet = textToSynthesize.take(120),
                        fullScript = textToSynthesize,
                        voiceLabel = voiceName,
                        languageLabel = st.groups.firstOrNull { it.id == st.selectedGroupId }?.label ?: "English",
                        durationSec = output.durationSec,
                        createdAtEpochMs = System.currentTimeMillis(),
                        wavFilePath = output.wavFile.absolutePath,
                        mp3FilePath = null,
                        isClonedVoice = clonedProfile != null,
                        accentLabel = if (clonedProfile != null) st.selectedTargetAccent.label else null
                    )
                    val updatedProjects = listOf(project) + _uiState.value.savedProjects
                    withContext(Dispatchers.IO) { prefsStore.saveProjects(updatedProjects) }
                    _uiState.update { it.copy(savedProjects = updatedProjects) }
                }
            } catch (ce: CancellationException) {
                _uiState.update {
                    it.copy(
                        progressPct = 0,
                        statusMessage = "Cancelled.",
                        isStatusError = false
                    )
                }
            } catch (e: Exception) {
                setStatus(e.message ?: "Generation failed.", isError = true)
            } finally {
                GenerationForegroundService.stop(context)
                _uiState.update { it.copy(isBusyGenerating = false) }
                activeGenerationJob = null
            }
        }
    }

    fun cancelGeneration() {
        activeGenerationJob?.cancel()
        setStatus("Cancelling...", isError = false)
    }

    private fun loadAndPlayFile(wavFile: File, peaks: FloatArray, samples: FloatArray) {
        try {
            val dur = audioPlayer.loadWavFile(wavFile)
            lastSynthesisSamples = samples
            _uiState.update {
                it.copy(
                    hasLoadedAudio = true,
                    currentWavFile = wavFile,
                    waveformPeaks = peaks,
                    totalAudioDurationSec = dur,
                    currentPlayheadSec = 0f
                )
            }
            playAudio()
        } catch (e: Exception) {
            setStatus("Audio playback error: ${e.message}", isError = true)
        }
    }

    fun togglePlayPause() {
        if (!_uiState.value.hasLoadedAudio) return
        if (audioPlayer.isPlaying) {
            pauseAudio()
        } else {
            if (_uiState.value.currentPlayheadSec >= _uiState.value.totalAudioDurationSec - 0.05f) {
                audioPlayer.seekToFraction(0f)
            }
            playAudio()
        }
    }

    private fun playAudio() {
        audioPlayer.play()
        _uiState.update { it.copy(isPlayingAudio = true) }
        playheadTickerJob?.cancel()
        playheadTickerJob = viewModelScope.launch {
            while (isActive && audioPlayer.isPlaying) {
                _uiState.update { it.copy(currentPlayheadSec = audioPlayer.currentPositionSec) }
                delay(33L)
            }
        }
    }

    fun pauseAudio() {
        audioPlayer.pause()
        playheadTickerJob?.cancel()
        _uiState.update { it.copy(isPlayingAudio = false) }
    }

    fun seekAudioToFraction(fraction: Float) {
        val f = fraction.coerceIn(0f, 1f)
        audioPlayer.seekToFraction(f)
        _uiState.update {
            it.copy(currentPlayheadSec = it.totalAudioDurationSec * f)
        }
    }

    fun suggestedExportFileName(extension: String): String {
        val st = _uiState.value
        val stamp = SimpleDateFormat("yyyyMMddHHmm", Locale.US).format(Date())
        val voiceTag = if (st.usePersonalClonedVoice) "myvoice" else st.mainVoice
        return "${st.lastGeneratedKind}-$voiceTag-$stamp.$extension"
    }

    fun exportAudioToUri(destUri: Uri, format: String) {
        val st = _uiState.value
        val wavFile = st.currentWavFile ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                withContext(Dispatchers.Main) {
                    setStatus("Preparing ${format.uppercase()} export...", isError = false)
                }
                if (format.equals("mp3", ignoreCase = true)) {
                    val samples = if (lastSynthesisSamples.isNotEmpty()) {
                        lastSynthesisSamples
                    } else {
                        FileInputStream(wavFile).use { AudioPipeline.decodeWavToMonoFloat24k(it) }
                    }
                    val tmpMp3 = File(context.cacheDir, "previews/export_temp.mp3")
                    AudioPipeline.writeMp3FileOffline(tmpMp3, samples, title = "VoiceStudio Voiceover")
                    context.contentResolver.openOutputStream(destUri)?.use { out ->
                        FileInputStream(tmpMp3).use { it.copyTo(out) }
                    }
                } else {
                    context.contentResolver.openOutputStream(destUri)?.use { out ->
                        FileInputStream(wavFile).use { it.copyTo(out) }
                    }
                }
                withContext(Dispatchers.Main) {
                    setStatus("Saved ${format.uppercase()} file successfully.", isError = false)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    setStatus("Export failed: ${e.message}", isError = true)
                }
            }
        }
    }

    fun shareCurrentAudio(format: String = "wav") {
        val st = _uiState.value
        val wavFile = st.currentWavFile ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val exportDir = File(context.filesDir, "exports").also { it.mkdirs() }
                val targetFile = File(exportDir, suggestedExportFileName(format))
                if (format.equals("mp3", ignoreCase = true)) {
                    val samples = if (lastSynthesisSamples.isNotEmpty()) {
                        lastSynthesisSamples
                    } else {
                        FileInputStream(wavFile).use { AudioPipeline.decodeWavToMonoFloat24k(it) }
                    }
                    AudioPipeline.writeMp3FileOffline(targetFile, samples)
                } else {
                    wavFile.copyTo(targetFile, overwrite = true)
                }
                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    targetFile
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = if (format == "mp3") "audio/mpeg" else "audio/wav"
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(shareIntent, "Share Voiceover").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    setStatus("Could not open share sheet: ${e.message}", isError = true)
                }
            }
        }
    }

    // ---------------- Projects / History Actions ----------------

    fun playSavedProject(project: SavedProjectItem) {
        val file = File(project.wavFilePath)
        if (!file.exists()) {
            setStatus("Audio file is no longer on disk.", isError = true)
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val bytes = file.readBytes()
            val peaks = AudioPipeline.extractWavPeaksFast(bytes, AudioPipeline.DEFAULT_PEAK_BARS)
            val samples = AudioPipeline.decodeWavToMonoFloat24k(bytes.inputStream())
            withContext(Dispatchers.Main) {
                loadAndPlayFile(file, peaks, samples)
                setStatus("Playing '${project.title}' (${formatDuration(project.durationSec)})", isError = false)
            }
        }
    }

    fun renameSavedProject(projectId: String, newTitle: String) {
        val clean = newTitle.trim()
        if (clean.isEmpty()) return
        val updated = _uiState.value.savedProjects.map {
            if (it.id == projectId) it.copy(title = clean) else it
        }
        _uiState.update { it.copy(savedProjects = updated) }
        viewModelScope.launch(Dispatchers.IO) { prefsStore.saveProjects(updated) }
    }

    fun deleteSavedProject(projectId: String) {
        val target = _uiState.value.savedProjects.firstOrNull { it.id == projectId }
        target?.let {
            File(it.wavFilePath).delete()
            it.mp3FilePath?.let { mp3 -> File(mp3).delete() }
        }
        val updated = _uiState.value.savedProjects.filterNot { it.id == projectId }
        _uiState.update { it.copy(savedProjects = updated) }
        viewModelScope.launch(Dispatchers.IO) { prefsStore.saveProjects(updated) }
    }

    // ---------------- Model Management Actions ----------------

    fun downloadModelPack(pack: ModelPackId) {
        viewModelScope.launch {
            _uiState.update { state ->
                state.copy(
                    enginePhase = EnginePhase.DOWNLOADING,
                    engineBadgeText = "Downloading ${pack.id}...",
                    modelPacks = state.modelPacks.map {
                        if (it.pack == pack) it.copy(isDownloading = true, progressPct = 0, statusMessage = "Starting download...")
                        else it
                    }
                )
            }
            try {
                modelStorage.downloadModelPack(pack) { msg, pct ->
                    _uiState.update { state ->
                        state.copy(
                            progressPct = pct,
                            statusMessage = msg,
                            modelPacks = state.modelPacks.map {
                                if (it.pack == pack) it.copy(isDownloading = true, progressPct = pct, statusMessage = msg)
                                else it
                            }
                        )
                    }
                }
                refreshModelPackStatus()
            } catch (e: Exception) {
                setStatus("Download failed: ${e.message}", isError = true)
                refreshModelPackStatus()
            }
        }
    }

    fun importModelFileUri(uri: Uri, displayName: String?) {
        viewModelScope.launch {
            try {
                setStatus("Importing model file into local app storage...", isError = false)
                val summary = modelStorage.importModelFromUri(uri, displayName) { msg ->
                    _uiState.update { it.copy(statusMessage = msg) }
                }
                setStatus(summary, isError = false)
                refreshModelPackStatus()
            } catch (e: Exception) {
                setStatus("Model import failed: ${e.message}", isError = true)
            }
        }
    }

    fun deleteModelPack(pack: ModelPackId) {
        viewModelScope.launch(Dispatchers.IO) {
            modelStorage.deleteModelPack(pack)
            withContext(Dispatchers.Main) {
                refreshModelPackStatus()
            }
        }
    }

    // ---------------- Helpers ----------------

    private fun setStatus(msg: String, isError: Boolean) {
        _uiState.update { it.copy(statusMessage = msg, isStatusError = isError) }
    }

    private fun schedulePrefsSave() {
        saveDebounceJob?.cancel()
        saveDebounceJob = viewModelScope.launch {
            delay(300L)
            flushPrefsNow()
        }
    }

    fun flushPrefsNow() {
        val st = _uiState.value
        viewModelScope.launch(Dispatchers.IO) {
            prefsStore.saveStudioPrefs(
                SavedStudioPrefs(
                    script = st.script,
                    voice = st.mainVoice,
                    blendVoice = st.blendVoice,
                    blendPercent = st.blendPercent,
                    speedPercent = st.speedPercent,
                    styleId = st.selectedStyleId,
                    activePresetIndex = st.activePresetIndex,
                    libGroup = st.selectedGroupId,
                    libGender = st.selectedGender,
                    libSel = st.selectedLibraryId,
                    favs = st.favorites.toList(),
                    selectedClonedVoiceId = if (st.usePersonalClonedVoice) st.selectedPersonalVoiceId else "",
                    selectedTargetAccentId = st.selectedTargetAccent.id
                )
            )
        }
    }

    fun formatDuration(seconds: Float): String {
        val clean = seconds.coerceAtLeast(0f).toInt()
        val m = clean / 60
        val s = clean % 60
        return String.format("%d:%02d", m, s)
    }

    override fun onCleared() {
        super.onCleared()
        flushPrefsNow()
        audioPlayer.release()
    }
}
