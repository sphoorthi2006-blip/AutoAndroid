# Third-Party Licenses & Open-Source Notices

VoiceStudio for Android integrates or interoperates with the following open-source software and machine learning models:

1. **Kokoro-82M Model Weights & Voice Embeddings (`kokoro-v1.0.onnx`, `voices-v1.0.bin`)**
   - **Author / Source:** `hexgrad/Kokoro-82M` (https://huggingface.co/hexgrad/Kokoro-82M) & ONNX export by `thewh1teagle/kokoro-onnx` (https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.0)
   - **License:** Apache License 2.0

2. **OpenVoice V2 Reference Voice Cloning & Tone Color Converter (`tone_extract.onnx`, `tone_color.onnx`)**
   - **Author / Source:** MyShell AI (`myshell-ai/OpenVoice`) & ONNX export by `Hinotsuba/OpenVoice-ONNX-v2` (https://huggingface.co/Hinotsuba/OpenVoice-ONNX-v2)
   - **License:** MIT License (Copyright (c) 2024 MyShell.ai)

3. **Meta MMS-TTS Telugu VITS Model (`facebook/mms-tts-tel` / `naklitechie/mms-tts-te-ONNX`)**
   - **Author / Source:** Meta AI (`facebook/mms-tts-tel`, https://huggingface.co/facebook/mms-tts-tel)
   - **License:** Creative Commons Attribution-NonCommercial 4.0 International (CC-BY-NC 4.0)

4. **Microsoft ONNX Runtime Mobile for Android (`com.microsoft.onnxruntime:onnxruntime-android`)**
   - **Author / Source:** Microsoft Corporation (https://github.com/microsoft/onnxruntime)
   - **License:** MIT License

5. **Android Jetpack Compose, AndroidX Core, Lifecycle, Navigation & DataStore**
   - **Author / Source:** The Android Open Source Project (AOSP)
   - **License:** Apache License 2.0
