package com.voicestudio.android.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.voicestudio.android.data.model.PersonalVoiceProfile
import com.voicestudio.android.data.model.SavedProjectItem
import com.voicestudio.android.data.model.TargetAccent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private val Context.studioDataStore: DataStore<Preferences> by preferencesDataStore(name = "voicestudio_prefs")

/**
 * Snapshot of the 11 studio keys persisted in the original Chrome extension (`STORAGE_KEYS` in `studio.js`)
 * plus active cloned voice and accent preferences.
 */
data class SavedStudioPrefs(
    val script: String = "",
    val voice: String = "af_heart",
    val blendVoice: String = "",
    val blendPercent: Int = 0,
    val speedPercent: Int = 100,
    val styleId: String = "conversational",
    val activePresetIndex: Int = -1,
    val libGroup: String = "en-us",
    val libGender: String = "all",
    val libSel: String = "en-us:f:af_heart",
    val favs: List<String> = emptyList(),
    val selectedClonedVoiceId: String = "",
    val selectedTargetAccentId: String = TargetAccent.AMERICAN_ENGLISH.id
)

class StudioPreferencesStore(private val context: Context) {

    companion object {
        private val KEY_SCRIPT = stringPreferencesKey("script")
        private val KEY_VOICE = stringPreferencesKey("voice")
        private val KEY_BLEND_VOICE = stringPreferencesKey("blendVoice")
        private val KEY_BLEND = intPreferencesKey("blend")
        private val KEY_SPEED = intPreferencesKey("speed")
        private val KEY_STYLE = stringPreferencesKey("style")
        private val KEY_PRESET = intPreferencesKey("preset")
        private val KEY_LIB_GROUP = stringPreferencesKey("libGroup")
        private val KEY_LIB_GENDER = stringPreferencesKey("libGender")
        private val KEY_LIB_SEL = stringPreferencesKey("libSel")
        private val KEY_FAVS = stringSetPreferencesKey("favs")
        private val KEY_CLONED_VOICE_ID = stringPreferencesKey("selectedClonedVoiceId")
        private val KEY_TARGET_ACCENT = stringPreferencesKey("selectedTargetAccentId")
    }

    val prefsFlow: Flow<SavedStudioPrefs> = context.studioDataStore.data.map { p ->
        SavedStudioPrefs(
            script = p[KEY_SCRIPT] ?: "",
            voice = p[KEY_VOICE] ?: "af_heart",
            blendVoice = p[KEY_BLEND_VOICE] ?: "",
            blendPercent = p[KEY_BLEND] ?: 0,
            speedPercent = p[KEY_SPEED] ?: 100,
            styleId = p[KEY_STYLE] ?: "conversational",
            activePresetIndex = p[KEY_PRESET] ?: -1,
            libGroup = p[KEY_LIB_GROUP] ?: "en-us",
            libGender = p[KEY_LIB_GENDER] ?: "all",
            libSel = p[KEY_LIB_SEL] ?: "en-us:f:af_heart",
            favs = (p[KEY_FAVS] ?: emptySet()).toList(),
            selectedClonedVoiceId = p[KEY_CLONED_VOICE_ID] ?: "",
            selectedTargetAccentId = p[KEY_TARGET_ACCENT] ?: TargetAccent.AMERICAN_ENGLISH.id
        )
    }

    suspend fun saveStudioPrefs(state: SavedStudioPrefs) {
        context.studioDataStore.edit { p ->
            p[KEY_SCRIPT] = state.script
            p[KEY_VOICE] = state.voice
            p[KEY_BLEND_VOICE] = state.blendVoice
            p[KEY_BLEND] = state.blendPercent
            p[KEY_SPEED] = state.speedPercent
            p[KEY_STYLE] = state.styleId
            p[KEY_PRESET] = state.activePresetIndex
            p[KEY_LIB_GROUP] = state.libGroup
            p[KEY_LIB_GENDER] = state.libGender
            p[KEY_LIB_SEL] = state.libSel
            p[KEY_FAVS] = state.favs.toSet()
            p[KEY_CLONED_VOICE_ID] = state.selectedClonedVoiceId
            p[KEY_TARGET_ACCENT] = state.selectedTargetAccentId
        }
    }

    // Local JSON-backed persistence for PersonalVoiceProfiles and SavedProjectItems
    private val profilesFile: File
        get() = File(context.filesDir, "my_voices/profiles.json").also { it.parentFile?.mkdirs() }

    private val projectsFile: File
        get() = File(context.filesDir, "projects/history.json").also { it.parentFile?.mkdirs() }

    fun loadPersonalVoiceProfiles(): List<PersonalVoiceProfile> {
        if (!profilesFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(profilesFile.readText())
            val out = ArrayList<PersonalVoiceProfile>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val accentId = o.optString("preferredAccent", TargetAccent.AMERICAN_ENGLISH.id)
                val accent = TargetAccent.entries.firstOrNull { it.id == accentId } ?: TargetAccent.AMERICAN_ENGLISH
                out.add(
                    PersonalVoiceProfile(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        createdAtEpochMs = o.getLong("createdAtEpochMs"),
                        referenceWavPath = o.getString("referenceWavPath"),
                        referenceDurationSec = o.optDouble("referenceDurationSec", 5.0).toFloat(),
                        trimStartSec = o.optDouble("trimStartSec", 0.0).toFloat(),
                        trimEndSec = o.optDouble("trimEndSec", 5.0).toFloat(),
                        toneEmbeddingPath = o.getString("toneEmbeddingPath"),
                        consentConfirmed = o.optBoolean("consentConfirmed", true),
                        preferredAccent = accent
                    )
                )
            }
            out.sortedByDescending { it.createdAtEpochMs }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun savePersonalVoiceProfiles(profiles: List<PersonalVoiceProfile>) {
        val arr = JSONArray()
        for (p in profiles) {
            arr.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("name", p.name)
                    put("createdAtEpochMs", p.createdAtEpochMs)
                    put("referenceWavPath", p.referenceWavPath)
                    put("referenceDurationSec", p.referenceDurationSec.toDouble())
                    put("trimStartSec", p.trimStartSec.toDouble())
                    put("trimEndSec", p.trimEndSec.toDouble())
                    put("toneEmbeddingPath", p.toneEmbeddingPath)
                    put("consentConfirmed", p.consentConfirmed)
                    put("preferredAccent", p.preferredAccent.id)
                }
            )
        }
        profilesFile.writeText(arr.toString(2))
    }

    fun loadSavedProjects(): List<SavedProjectItem> {
        if (!projectsFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(projectsFile.readText())
            val out = ArrayList<SavedProjectItem>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    SavedProjectItem(
                        id = o.getString("id"),
                        title = o.getString("title"),
                        scriptSnippet = o.getString("scriptSnippet"),
                        fullScript = o.optString("fullScript", o.getString("scriptSnippet")),
                        voiceLabel = o.getString("voiceLabel"),
                        languageLabel = o.optString("languageLabel", "English"),
                        durationSec = o.optDouble("durationSec", 0.0).toFloat(),
                        createdAtEpochMs = o.getLong("createdAtEpochMs"),
                        wavFilePath = o.getString("wavFilePath"),
                        mp3FilePath = o.optString("mp3FilePath").takeIf { it.isNotEmpty() },
                        isClonedVoice = o.optBoolean("isClonedVoice", false),
                        accentLabel = o.optString("accentLabel").takeIf { it.isNotEmpty() }
                    )
                )
            }
            out.sortedByDescending { it.createdAtEpochMs }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveProjects(projects: List<SavedProjectItem>) {
        val arr = JSONArray()
        for (p in projects) {
            arr.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("title", p.title)
                    put("scriptSnippet", p.scriptSnippet)
                    put("fullScript", p.fullScript)
                    put("voiceLabel", p.voiceLabel)
                    put("languageLabel", p.languageLabel)
                    put("durationSec", p.durationSec.toDouble())
                    put("createdAtEpochMs", p.createdAtEpochMs)
                    put("wavFilePath", p.wavFilePath)
                    put("mp3FilePath", p.mp3FilePath ?: "")
                    put("isClonedVoice", p.isClonedVoice)
                    put("accentLabel", p.accentLabel ?: "")
                }
            )
        }
        projectsFile.writeText(arr.toString(2))
    }
}
