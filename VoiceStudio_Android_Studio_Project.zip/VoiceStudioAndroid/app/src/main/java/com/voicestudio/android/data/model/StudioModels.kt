package com.voicestudio.android.data.model

/**
 * Engine readiness phases matching original server.py STATE["phase"] plus granular pack status.
 */
enum class EnginePhase(val wireName: String) {
    STARTING("starting"),
    MISSING_MODELS("missing"),
    DOWNLOADING("downloading"),
    LOADING("loading"),
    READY("ready"),
    ERROR("error")
}

/**
 * Supported language / accent groups preserving all 7 original Kokoro groups + native Telugu (te-in).
 */
data class LanguageGroup(
    val id: String,
    val prefix: Char,
    val espeakLang: String,
    val label: String,
    val count: Int,
    val isTeluguNative: Boolean = false
)

/**
 * Entry in the Voice Library (single base voice, 60/40 combinatoric blend, or Telugu VITS voice).
 */
data class VoiceLibraryEntry(
    val id: String,
    val group: String,
    val gender: String, // "Female" or "Male"
    val name: String,
    val voice: String,
    val blendVoice: String?,
    val blend: Float,
    val kind: String // "single", "blend", or "telugu_vits"
)

/**
 * One-click curated preset matching _PRESET_DATA in tts_core.py.
 */
data class VoicePreset(
    val index: Int,
    val name: String,
    val desc: String,
    val voice: String,
    val blendVoice: String,
    val blend: Float,
    val speed: Float,
    val style: String
)

/**
 * Conversation pacing style matching STYLES in tts_core.py.
 */
data class ConversationStyle(
    val id: String,
    val label: String,
    val desc: String,
    val maxChars: Int,
    val jitter: Float,
    val paraPauseSec: Float,
    val shortPauseMinSec: Float,
    val shortPauseMaxSec: Float,
    val questionBonusSec: Float,
    val speedMultiplier: Float
)

/**
 * Personal cloned voice profile created in the "My Voice" section using OpenVoice V2 tone_extract.onnx.
 */
data class PersonalVoiceProfile(
    val id: String,
    val name: String,
    val createdAtEpochMs: Long,
    val referenceWavPath: String,
    val referenceDurationSec: Float,
    val trimStartSec: Float,
    val trimEndSec: Float,
    val toneEmbeddingPath: String, // 256-float speaker embedding vector extracted by tone_extract.onnx
    val consentConfirmed: Boolean,
    val preferredAccent: TargetAccent = TargetAccent.AMERICAN_ENGLISH
)

/**
 * Target accents for Accent Adaptation in My Voice cloning.
 */
enum class TargetAccent(
    val id: String,
    val label: String,
    val flagEmoji: String,
    val description: String,
    val baseFemaleKokoroVoice: String,
    val baseMaleKokoroVoice: String,
    val phonemizerCode: String
) {
    AMERICAN_ENGLISH(
        id = "en-us",
        label = "American English",
        flagEmoji = "🇺🇸",
        description = "General American rhotic pronunciation and cadence (Kokoro en-us base + OpenVoice V2 timbre conversion)",
        baseFemaleKokoroVoice = "af_heart",
        baseMaleKokoroVoice = "am_michael",
        phonemizerCode = "en-us"
    ),
    BRITISH_ENGLISH(
        id = "en-gb",
        label = "British English",
        flagEmoji = "🇬🇧",
        description = "Received Pronunciation / Southern British cadence (Kokoro en-gb base + OpenVoice V2 timbre conversion)",
        baseFemaleKokoroVoice = "bf_emma",
        baseMaleKokoroVoice = "bm_george",
        phonemizerCode = "en-gb"
    ),
    AUSTRALIAN_ENGLISH(
        id = "en-au",
        label = "Australian English",
        flagEmoji = "🇦🇺",
        description = "Australian English vowel shifts & non-rhotic G2P rules driving base synthesis + OpenVoice V2 timbre conversion",
        baseFemaleKokoroVoice = "bf_isabella",
        baseMaleKokoroVoice = "bm_lewis",
        phonemizerCode = "en-au"
    ),
    INDIAN_ENGLISH(
        id = "en-in",
        label = "Indian English",
        flagEmoji = "🇮🇳",
        description = "Indian English syllable-timed prosody, retroflex coronal stops & rhotic G2P rules + OpenVoice V2 timbre conversion",
        baseFemaleKokoroVoice = "af_sarah",
        baseMaleKokoroVoice = "am_liam",
        phonemizerCode = "en-in"
    )
}

/**
 * Saved generation entry in Projects & History.
 */
data class SavedProjectItem(
    val id: String,
    val title: String,
    val scriptSnippet: String,
    val fullScript: String,
    val voiceLabel: String,
    val languageLabel: String,
    val durationSec: Float,
    val createdAtEpochMs: Long,
    val wavFilePath: String,
    val mp3FilePath: String?,
    val isClonedVoice: Boolean = false,
    val accentLabel: String? = null
)

/**
 * Offline downloadable / importable AI model pack status.
 */
enum class ModelPackId(
    val id: String,
    val title: String,
    val subtitle: String,
    val licenseName: String,
    val expectedTotalBytes: Long
) {
    KOKORO_CORE(
        id = "kokoro_v1",
        title = "Kokoro-82M Core Voice Engine (v1.0)",
        subtitle = "41 base voices + 214 blends across US/UK English, Hindi, Spanish, French, Italian & Portuguese",
        licenseName = "Apache License 2.0",
        expectedTotalBytes = 369_523_898L // kokoro-v1.0.onnx (~341.3MB) + voices-v1.0.bin (28.2MB)
    ),
    OPENVOICE_CLONING(
        id = "openvoice_v2",
        title = "OpenVoice V2 Zero-Shot Voice Cloning & Accent Pack",
        subtitle = "tone_extract.onnx (speaker encoder) + tone_color.onnx (timbre & cross-accent converter)",
        licenseName = "MIT License (MyShell OpenVoice V2)",
        expectedTotalBytes = 132_400_000L
    ),
    MMS_TELUGU_VITS(
        id = "mms_tts_tel",
        title = "Meta MMS-TTS Telugu Native VITS Engine",
        subtitle = "End-to-end native Telugu script (తెలుగు) speech synthesis model (mms-tts-tel ONNX)",
        licenseName = "CC-BY-NC 4.0 (Meta AI MMS-TTS)",
        expectedTotalBytes = 114_294_784L
    )
}

data class ModelPackStatus(
    val pack: ModelPackId,
    val isInstalled: Boolean,
    val isDownloading: Boolean = false,
    val progressPct: Int = 0,
    val statusMessage: String = "",
    val diskBytesUsed: Long = 0L,
    val sha256Verified: Boolean = false
)
