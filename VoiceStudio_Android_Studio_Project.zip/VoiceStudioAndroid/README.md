# VoiceStudio for Android — Standalone Offline AI Voiceover, Voice Cloning & Telugu Studio

VoiceStudio for Android is a native **Kotlin + Jetpack Compose** standalone Android application converted from the original `VoiceStudio` Chrome Extension + Python (`kokoro-onnx`) desktop project, expanded with **My Voice (Zero-Shot Reference-Audio Voice Cloning)**, **Cross-Accent Adaptation (US, UK, Australian, Indian English)**, and **Native Offline Telugu (`తెలుగు`) Speech Synthesis**.

## 1. Key Capabilities

- **100% Standalone & Offline Operation:** Runs directly on your Android phone using **ONNX Runtime Mobile (`com.microsoft.onnxruntime:onnxruntime-android:1.20.0`)**. No PC, no local server (`server.py`), no browser extension, and no cloud TTS APIs. Works in Airplane Mode once models are installed or imported.
- **Original VoiceStudio Parity:**
  - **41 Base Kokoro-82M Voices + 214 Ready-Made 60/40 Blends** across American English (`en-us`), British English (`en-gb`), Hindi (`hi`), Spanish (`es`), French (`fr-fr`), Italian (`it`), and Brazilian Portuguese (`pt-br`) with the exact deterministic human names (`Yara`, `Sienna`, `Ivy`, `Stan`, `Otis`, etc.) from `tts_core.py`.
  - **12 Quick-Pick Curated Presets:** *Warm Storyteller, Friendly Chat, Calm Devotional, Energetic Host, Clear Educator, British Lady, Deep Storyteller, Deep Authority, Calm Guide, Friendly Guy, Documentary,* and *Dark Documentary*.
  - **7 Conversation Pacing Styles:** *Conversational, Storytelling, Energetic, Calm & soothing, Documentary, Clear narration,* and *Plain* (preserving `random.Random(7)` jitter and paragraph/question pause timing).
  - **Custom Two-Voice Mixer:** Blend any primary voice with any secondary voice from `0%` to `100%` linear style interpolation (`(1 - blend) * A + blend * B`).
  - **Script Tools & Waveform Scrubber:** Supports `.txt` file import, `+ Pause` (`[pause 1]`, `[pause 2.5]`), live word count & duration estimation, 16-entry LRU preview cache, 1,200-bar dual-layer interactive waveform scrubbing, and offline **Save WAV (`PCM_16` 24 kHz)**, **Save MP3**, and Android Share Sheet export.
- **My Voice — Zero-Shot Reference Audio Voice Cloning (`OpenVoice V2 ONNX`):**
  - Record your voice directly with the phone microphone (`AudioRecord` @ 24 kHz) or import a `.wav` recording.
  - Preview and trim start/end points with an interactive range slider.
  - Extracts a 256-dimensional vocal timbre embedding via `tone_extract.onnx` (`float32[1, frames, 513] -> float32[1, 256]`) and converts base speech via `tone_color.onnx` (`Hinotsuba/OpenVoice-ONNX-v2`).
  - Requires explicit speaker ownership/permission consent before creating a profile. All recordings and embeddings stay in private local app storage (`files/my_voices/`).
- **Accent Adaptation (US, UK, Australian & Indian English):**
  - Synthesizes the base phonetic & prosodic contour using regional pronunciation rules (American, British, Australian, or Indian English) and applies OpenVoice V2 tone color conversion (`tone_color.onnx`) to retain the cloned speaker's vocal identity across accents.
- **Native Telugu (`తెలుగు`) Language Support (`MMS-TTS Telugu VITS ONNX`):**
  - Full Telugu Unicode script editor support, one-tap Telugu sample sentences (*పరిచయం, వార్త, కథనం, సామెత*), and offline Telugu speech synthesis powered by Meta's `facebook/mms-tts-tel` (`naklitechie/mms-tts-te-ONNX`) 65-symbol native Telugu VITS model (`is_uroman: false`), plus a built-in Telugu formant fallback so Telugu script synthesis works even before downloading the 109 MB neural pack.

## 2. Building the Debug APK (`app-debug.apk`)

### Prerequisites
- **Android Studio Ladybug (2024.2.1)+** or Android SDK Command-Line Tools with **SDK Platform 35** and **JDK 17**.

### Build Commands
From the `VoiceStudioAndroid/` project root:

- **macOS / Linux:**
  ```bash
  ./gradlew assembleDebug
  ```
- **Windows:**
  ```bat
  gradlew.bat assembleDebug
  ```

### Output APK Location
```text
app/build/outputs/apk/debug/app-debug.apk
```

### Run Automated Unit Tests
```bash
./gradlew testDebugUnitTest
```

## 3. Installing or Importing Offline AI Models

Open the **Models** tab inside the app:
1. **One-Tap Official Download:** Tap **Download Official Pack** on:
   - **Kokoro-82M Core Voice Engine (`v1.0`)**: Downloads `kokoro-v1.0.onnx` (325.5 MB, SHA-256 `7d5df8ecf7d4b1878015a32686053fd0eebe2bc377234608764cc0ef3636a6c5`) and `voices-v1.0.bin` (28.2 MB, SHA-256 `bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d`) from `github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/`.
   - **OpenVoice V2 Cloning & Accent Pack**: Downloads `tone_extract.onnx` and `tone_color.onnx` from `huggingface.co/Hinotsuba/OpenVoice-ONNX-v2`.
   - **Meta MMS-TTS Telugu VITS Pack**: Downloads `mms-tts-tel.onnx` (`model.onnx`) from `huggingface.co/naklitechie/mms-tts-te-ONNX`.
2. **100% Offline Manual Import (No Internet Required):**
   - Copy `kokoro-v1.0.onnx`, `voices-v1.0.bin` (or `VoiceStudio-Models.zip`), `tone_extract.onnx`, `tone_color.onnx`, or `mms-tts-tel.onnx` to your phone via USB.
   - Tap **Import Model File (.onnx / .bin / .zip) From Device** in the **Models** tab and select the file(s).
   - Enable **Airplane Mode** and generate voiceovers completely offline.
