package com.voicestudio.android.data.repository

import android.content.Context
import android.util.LruCache
import com.voicestudio.android.audio.AudioPipeline
import com.voicestudio.android.data.model.ConversationStyle
import com.voicestudio.android.data.model.PersonalVoiceProfile
import com.voicestudio.android.data.model.TargetAccent
import com.voicestudio.android.domain.ScriptPlanner
import com.voicestudio.android.domain.VoiceStudioCatalog
import com.voicestudio.android.engine.KokoroOnnxEngine
import com.voicestudio.android.engine.OpenVoiceCloningEngine
import com.voicestudio.android.engine.TeluguVitsOnnxEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import kotlin.coroutines.coroutineContext
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Result of a preview or full voiceover synthesis run.
 */
data class SynthesisOutput(
    val jobId: String,
    val wavFile: File,
    val samples: FloatArray,
    val sampleRate: Int,
    val durationSec: Float,
    val peaks: FloatArray,
    val usedNeuralEngine: Boolean,
    val engineSummaryNote: String
)

/**
 * Coordinates all three on-device engines (`KokoroOnnxEngine`, `TeluguVitsOnnxEngine`, and `OpenVoiceCloningEngine`),
 * implements the 16-item LRU preview cache (`previewCache` in `studio.js`), and runs multi-chunk
 * synthesis with per-chunk progress and estimated time remaining (`Generating X/Y - about M:SS left`).
 */
class VoiceSynthesisCoordinator(
    private val context: Context,
    val modelStorage: ModelStorageManager
) {
    private val kokoroEngine = KokoroOnnxEngine()
    private val teluguEngine = TeluguVitsOnnxEngine()
    private val cloningEngine = OpenVoiceCloningEngine()
    private val engineMutex = Mutex()

    // 16-entry LRU cache matching PREVIEW_CACHE_MAX = 16 in studio.js
    private val previewCache = object : LruCache<String, SynthesisOutput>(16) {}

    val isKokoroNeuralLoaded: Boolean get() = kokoroEngine.isLoaded
    val isTeluguNeuralLoaded: Boolean get() = teluguEngine.isNeuralModelLoaded
    val isOpenVoiceNeuralLoaded: Boolean get() = cloningEngine.isNeuralCloningLoaded

    suspend fun initializeInstalledModels(onStatus: (String) -> Unit) = withContext(Dispatchers.IO) {
        engineMutex.withLock {
            if (modelStorage.isKokoroReady() && !kokoroEngine.isLoaded) {
                onStatus("Loading Kokoro-82M ONNX voice engine...")
                try {
                    kokoroEngine.load(modelStorage.kokoroOnnxFile, modelStorage.kokoroVoicesFile)
                } catch (e: Exception) {
                    onStatus("Kokoro load error: ${e.message}")
                }
            }
            if (modelStorage.isOpenVoiceReady() && !cloningEngine.isNeuralCloningLoaded) {
                onStatus("Loading OpenVoice V2 cloning & accent engine...")
                try {
                    cloningEngine.load(modelStorage.openVoiceExtractFile, modelStorage.openVoiceColorFile)
                } catch (_: Exception) {
                }
            }
            if (modelStorage.isTeluguVitsReady() && !teluguEngine.isNeuralModelLoaded) {
                onStatus("Loading MMS-TTS Telugu VITS engine...")
                try {
                    teluguEngine.load(modelStorage.teluguVitsFile)
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * Synthesize a preview or full voiceover offline.
     */
    suspend fun synthesizeScript(
        text: String,
        voice: String,
        blendVoice: String?,
        blendRatio: Float,
        speed: Float,
        style: ConversationStyle,
        isPreview: Boolean,
        clonedProfile: PersonalVoiceProfile? = null,
        targetAccent: TargetAccent? = null,
        onProgress: (message: String, pct: Int) -> Unit
    ): SynthesisOutput = withContext(Dispatchers.Default) {
        val cleanText = text.trim()
        require(cleanText.isNotEmpty()) { "The script is empty. Paste or type your script first." }
        require(cleanText.length <= 400_000) { "The script exceeds the 400,000-character limit." }

        val cacheKey = if (isPreview) {
            "$cleanText|$voice|${blendVoice.orEmpty()}|$blendRatio|$speed|${style.id}|${clonedProfile?.id.orEmpty()}|${targetAccent?.id.orEmpty()}"
        } else null

        if (cacheKey != null) {
            val cached = previewCache.get(cacheKey)
            if (cached != null && cached.wavFile.exists()) {
                return@withContext cached
            }
        }

        initializeInstalledModels { msg -> onProgress(msg, 0) }

        val steps = ScriptPlanner.buildSynthesisPlan(cleanText, speed, style)
        val totalSpeakSteps = steps.count { it is ScriptPlanner.SynthesisStep.SpeakStep }
        require(totalSpeakSteps > 0) { "The script contains no speakable text." }

        val isTeluguScript = voice.startsWith("tf_") || voice.startsWith("tm_") ||
                cleanText.any { it.code in 0x0C00..0x0C7F }

        val startTimeMs = System.currentTimeMillis()
        var completedSpeak = 0
        val chunkArrays = ArrayList<FloatArray>(steps.size * 2)

        for (step in steps) {
            coroutineContext.ensureActive()
            when (step) {
                is ScriptPlanner.SynthesisStep.SilenceStep -> {
                    val silenceSamples = (AudioPipeline.SAMPLE_RATE * step.seconds).roundToInt().coerceAtLeast(0)
                    chunkArrays.add(FloatArray(silenceSamples))
                }
                is ScriptPlanner.SynthesisStep.SpeakStep -> {
                    val rawChunkAudio = synthesizeSingleSpeakStep(
                        chunkText = step.text,
                        voice = voice,
                        blendVoice = blendVoice,
                        blendRatio = blendRatio,
                        effectiveSpeed = step.effectiveSpeed,
                        isTelugu = isTeluguScript,
                        clonedProfile = clonedProfile,
                        targetAccent = targetAccent
                    )
                    chunkArrays.add(rawChunkAudio)
                    val gapSamples = (AudioPipeline.SAMPLE_RATE * step.postGapSeconds).roundToInt().coerceAtLeast(0)
                    if (gapSamples > 0) {
                        chunkArrays.add(FloatArray(gapSamples))
                    }
                    completedSpeak++
                    val pct = ((completedSpeak * 100f) / totalSpeakSteps).roundToInt().coerceIn(1, 99)
                    var msg = "Generating $completedSpeak/$totalSpeakSteps"
                    if (completedSpeak in 3 until totalSpeakSteps) {
                        val elapsedSec = (System.currentTimeMillis() - startTimeMs) / 1000f
                        val remainingSec = (elapsedSec / completedSpeak) * (totalSpeakSteps - completedSpeak)
                        val remMin = (remainingSec / 60f).toInt()
                        val remSec = (remainingSec % 60f).toInt()
                        msg += String.format(" - about %d:%02d left", remMin, remSec)
                    }
                    onProgress(msg, pct)
                }
            }
        }

        coroutineContext.ensureActive()
        val totalSamples = chunkArrays.sumOf { it.size }
        val combined = FloatArray(totalSamples)
        var pos = 0
        for (arr in chunkArrays) {
            System.arraycopy(arr, 0, combined, pos, arr.size)
            pos += arr.size
        }

        AudioPipeline.normalizePeakInPlace(combined, 0.98f)
        val peaks = AudioPipeline.extractPeaksFromSamples(combined, AudioPipeline.DEFAULT_PEAK_BARS)
        val jobId = UUID.randomUUID().toString().take(12)
        val outDir = if (isPreview) {
            File(context.cacheDir, "previews").also { it.mkdirs() }
        } else {
            File(context.filesDir, "projects").also { it.mkdirs() }
        }
        val wavFile = File(outDir, "${if (isPreview) "preview" else "voiceover"}-$jobId.wav")
        AudioPipeline.writeWavFile(wavFile, combined, AudioPipeline.SAMPLE_RATE)

        val usedNeural = if (isTeluguScript) teluguEngine.isNeuralModelLoaded else kokoroEngine.isLoaded
        val engineNote = buildString {
            if (isTeluguScript) {
                append(if (teluguEngine.isNeuralModelLoaded) "MMS-TTS Telugu VITS (ONNX)" else "Telugu Offline Formant Fallback (Install MMS-TTS Telugu pack in Models for neural VITS)")
            } else {
                append(if (kokoroEngine.isLoaded) "Kokoro-82M v1.0 (ONNX)" else "Built-in Offline Acoustic Synth (Install Kokoro-82M in Models for neural voices)")
            }
            if (clonedProfile != null) {
                append(" + My Voice '${clonedProfile.name}'")
                if (targetAccent != null) {
                    append(" (${targetAccent.label})")
                }
            }
        }

        val output = SynthesisOutput(
            jobId = jobId,
            wavFile = wavFile,
            samples = combined,
            sampleRate = AudioPipeline.SAMPLE_RATE,
            durationSec = combined.size.toFloat() / AudioPipeline.SAMPLE_RATE,
            peaks = peaks,
            usedNeuralEngine = usedNeural,
            engineSummaryNote = engineNote
        )
        if (cacheKey != null) {
            previewCache.put(cacheKey, output)
        }
        return@withContext output
    }

    private suspend fun synthesizeSingleSpeakStep(
        chunkText: String,
        voice: String,
        blendVoice: String?,
        blendRatio: Float,
        effectiveSpeed: Float,
        isTelugu: Boolean,
        clonedProfile: PersonalVoiceProfile?,
        targetAccent: TargetAccent?
    ): FloatArray = engineMutex.withLock {
        val baseAudio: FloatArray = if (isTelugu) {
            teluguEngine.synthesizeTelugu(chunkText, voice, effectiveSpeed)
        } else {
            val baseVoice = if (clonedProfile != null && targetAccent != null) {
                targetAccent.baseFemaleKokoroVoice
            } else {
                voice
            }
            val phonemeLangOverride = if (clonedProfile != null && targetAccent != null) {
                targetAccent.phonemizerCode
            } else null

            if (kokoroEngine.isLoaded) {
                kokoroEngine.synthesizeChunk(
                    chunkText = chunkText,
                    voice = baseVoice,
                    blendVoice = if (clonedProfile != null) null else blendVoice,
                    blendRatio = if (clonedProfile != null) 0f else blendRatio,
                    speed = effectiveSpeed,
                    overridePhonemeLang = phonemeLangOverride
                )
            } else {
                // Offline harmonic formant fallback when the 325.5MB Kokoro ONNX file hasn't been downloaded yet
                TeluguVitsOnnxEngine.synthesizeTeluguKlattFallback(chunkText, baseVoice, effectiveSpeed)
            }
        }

        if (clonedProfile != null) {
            val embFile = File(clonedProfile.toneEmbeddingPath)
            if (embFile.exists()) {
                val targetEmb = OpenVoiceCloningEngine.loadEmbedding(embFile)
                return@withLock cloningEngine.convertToneColor(
                    baseAudio24k = baseAudio,
                    sourceToneEmbedding = null,
                    targetToneEmbedding = targetEmb,
                    tau = 0.3f
                )
            }
        }
        return@withLock baseAudio
    }

    /**
     * Extract a 256-float speaker embedding from a trimmed reference recording and save a PersonalVoiceProfile.
     */
    suspend fun createPersonalVoiceProfile(
        name: String,
        trimmedSamples24k: FloatArray,
        trimStartSec: Float,
        trimEndSec: Float,
        preferredAccent: TargetAccent,
        consentConfirmed: Boolean
    ): PersonalVoiceProfile = withContext(Dispatchers.Default) {
        require(consentConfirmed) { "Please confirm that you own or have permission to clone this voice." }
        require(trimmedSamples24k.size >= AudioPipeline.SAMPLE_RATE) {
            "Reference voice clip must be at least 1.0 second long."
        }
        val profileId = UUID.randomUUID().toString().take(10)
        val dir = File(context.filesDir, "my_voices").also { it.mkdirs() }
        val wavFile = File(dir, "ref_$profileId.wav")
        val embFile = File(dir, "emb_$profileId.bin")

        AudioPipeline.writeWavFile(wavFile, trimmedSamples24k, AudioPipeline.SAMPLE_RATE)
        val embedding = engineMutex.withLock {
            cloningEngine.extractSpeakerEmbedding(trimmedSamples24k)
        }
        OpenVoiceCloningEngine.saveEmbedding(embFile, embedding)

        PersonalVoiceProfile(
            id = profileId,
            name = name.trim().ifEmpty { "My Voice" },
            createdAtEpochMs = System.currentTimeMillis(),
            referenceWavPath = wavFile.absolutePath,
            referenceDurationSec = trimmedSamples24k.size.toFloat() / AudioPipeline.SAMPLE_RATE,
            trimStartSec = trimStartSec,
            trimEndSec = trimEndSec,
            toneEmbeddingPath = embFile.absolutePath,
            consentConfirmed = true,
            preferredAccent = preferredAccent
        )
    }
}
