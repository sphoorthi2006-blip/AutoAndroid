package com.voicestudio.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.voicestudio.android.domain.VoiceStudioCatalog
import com.voicestudio.android.ui.theme.StudioColors
import com.voicestudio.android.viewmodel.StudioUiState

/**
 * Main Studio Screen (`Studio` tab):
 * - Script Editor with `.txt` import, `+ Pause` (`[pause 1]`), `Clear`, word count, and duration estimate
 * - Telugu (`తెలుగు`) quick sample pills for one-tap Telugu Unicode script testing
 * - Active Voice / My Voice Cloned Profile + Accent banner
 * - Conversation Style selector & Speed slider (`0.60x - 1.50x`)
 * - Quick-Pick Preset horizontal carousel
 * - `Preview script`, `Generate full voiceover`, and `Cancel` buttons
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioScreen(
    state: StudioUiState,
    onScriptChange: (String) -> Unit,
    onOpenTxtClick: () -> Unit,
    onInsertPauseClick: () -> Unit,
    onClearScriptClick: () -> Unit,
    onTeluguSampleClick: (String) -> Unit,
    onStyleChange: (String) -> Unit,
    onSpeedChange: (Int) -> Unit,
    onPresetClick: (Int) -> Unit,
    onPreviewClick: () -> Unit,
    onGenerateClick: () -> Unit,
    onCancelClick: () -> Unit,
    onNavigateToVoices: () -> Unit,
    onNavigateToMyVoice: () -> Unit
) {
    val scrollState = rememberScrollState()
    var styleMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Active Voice / Cloned Voice Status Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (state.usePersonalClonedVoice) "ACTIVE PERSONAL CLONED VOICE" else "ACTIVE STUDIO VOICE",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (state.usePersonalClonedVoice) StudioColors.AccentTeal else StudioColors.TextMuted
                )
                Spacer(modifier = Modifier.height(3.dp))
                val activeLabel = if (state.usePersonalClonedVoice) {
                    val prof = state.personalVoices.firstOrNull { it.id == state.selectedPersonalVoiceId }
                    "${prof?.name ?: "My Voice"} • ${state.selectedTargetAccent.flagEmoji} ${state.selectedTargetAccent.label}"
                } else {
                    val base = VoiceStudioCatalog.friendlyVoiceLabel(state.mainVoice)
                    if (state.blendVoice.isNotBlank() && state.blendPercent > 0) {
                        "$base + ${state.blendPercent}% ${state.blendVoice.drop(3).replaceFirstChar { it.uppercase() }}"
                    } else {
                        base
                    }
                }
                Text(
                    text = activeLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = StudioColors.TextPrimary
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = onNavigateToVoices,
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Text("Voices", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onNavigateToMyVoice,
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Text("My Voice", fontSize = 12.sp, color = StudioColors.AccentTeal)
                }
            }
        }

        // Script Editor Panel
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "SCRIPT",
                    style = MaterialTheme.typography.labelSmall
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = onOpenTxtClick,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open .txt", fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = onInsertPauseClick,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.MoreTime, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Pause", fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = onClearScriptClick,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Clear", fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = state.script,
                onValueChange = onScriptChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 180.dp, max = 320.dp),
                placeholder = {
                    Text(
                        text = "Paste your script here (English, తెలుగు, हिन्दी, Español, Français, Italiano, Português). Use [pause] or [pause 2] for a pause. Leave empty and tap a preset to hear a sample line.",
                        color = StudioColors.TextMuted,
                        fontSize = 14.sp
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = StudioColors.PanelElevated,
                    unfocusedContainerColor = StudioColors.PanelElevated,
                    focusedBorderColor = StudioColors.AccentViolet,
                    unfocusedBorderColor = StudioColors.BorderLine,
                    focusedTextColor = StudioColors.TextPrimary,
                    unfocusedTextColor = StudioColors.TextPrimary
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${state.wordCount} words",
                    style = MaterialTheme.typography.bodySmall
                )
                val estMin = state.estimatedDurationSec / 60
                val estRem = state.estimatedDurationSec % 60
                Text(
                    text = if (state.wordCount > 0) String.format("about %d:%02d of audio", estMin, estRem) else "",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Telugu One-Tap Test Bar
            Text(
                text = "TELUGU (తెలుగు) QUICK SAMPLES:",
                style = MaterialTheme.typography.labelSmall,
                color = StudioColors.AccentTeal
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VoiceStudioCatalog.TELUGU_SAMPLE_SENTENCES.forEach { (label, teluguSentence) ->
                    FilterChip(
                        selected = state.script == teluguSentence,
                        onClick = { onTeluguSampleClick(teluguSentence) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StudioColors.PresetActiveSurface,
                            selectedLabelColor = StudioColors.AccentTeal
                        )
                    )
                }
            }
        }

        // Generation Controls (Preview & Full Generate)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onPreviewClick,
                enabled = !state.isBusyGenerating,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Preview script", fontWeight = FontWeight.SemiBold)
            }

            if (state.isBusyGenerating) {
                Button(
                    onClick = onCancelClick,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioColors.DangerRed)
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Cancel (${state.progressPct}%)", fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = onGenerateClick,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentViolet)
                ) {
                    Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Generate voiceover", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        // Pacing Style & Speed Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            val activeStyle = state.styles.firstOrNull { it.id == state.selectedStyleId } ?: state.styles.first()
            Text("CONVERSATION STYLE & SPEED", style = MaterialTheme.typography.labelSmall)
            Spacer(modifier = Modifier.height(8.dp))

            Box(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(9.dp))
                        .background(StudioColors.PanelElevated)
                        .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(9.dp))
                        .clickable { styleMenuExpanded = true }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(activeStyle.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Text(activeStyle.desc, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("▼", color = StudioColors.TextMuted)
                }

                DropdownMenu(
                    expanded = styleMenuExpanded,
                    onDismissRequest = { styleMenuExpanded = false },
                    modifier = Modifier.background(StudioColors.PanelElevated)
                ) {
                    state.styles.forEach { st ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(st.label, color = StudioColors.TextPrimary, fontWeight = FontWeight.SemiBold)
                                    Text(st.desc, color = StudioColors.TextMuted, fontSize = 11.5.sp)
                                }
                            },
                            onClick = {
                                onStyleChange(st.id)
                                styleMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Speed", style = MaterialTheme.typography.bodySmall)
                Text(
                    text = String.format("%.2fx", state.speedPercent / 100f),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = state.speedPercent.toFloat(),
                onValueChange = { onSpeedChange(it.toInt()) },
                valueRange = 60f..150f,
                colors = SliderDefaults.colors(
                    thumbColor = StudioColors.AccentViolet,
                    activeTrackColor = StudioColors.AccentViolet
                )
            )
        }

        // Quick Picks Presets Grid (12 curated presets from _PRESET_DATA)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Text(
                text = "QUICK PICKS (CURATED PRESETS — TAP TO HEAR)",
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(modifier = Modifier.height(10.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                maxItemsInEachRow = 2
            ) {
                state.presets.forEach { preset ->
                    val isSelected = state.activePresetIndex == preset.index && !state.usePersonalClonedVoice
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) StudioColors.PresetActiveSurface else StudioColors.PanelElevated)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) StudioColors.AccentTeal else StudioColors.BorderLine,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable(enabled = !state.isBusyGenerating) { onPresetClick(preset.index) }
                            .padding(10.dp)
                    ) {
                        Text(
                            text = preset.name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) StudioColors.AccentTeal else StudioColors.TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = preset.desc,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.5.sp,
                            maxLines = 2
                        )
                    }
                }
            }
        }
    }
}
