package com.voicestudio.android.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.voicestudio.android.data.model.EnginePhase
import com.voicestudio.android.ui.theme.StudioColors
import kotlin.math.max
import kotlin.math.min

/**
 * Top Studio Header with Brand Logo and Live Offline Engine Status Badge (`extension/studio.html`).
 */
@Composable
fun StudioTopHeader(
    enginePhase: EnginePhase,
    badgeText: String,
    onBadgeClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.Background)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(StudioColors.AccentViolet, StudioColors.AccentTeal)
                        )
                    )
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "Voice Studio",
                style = MaterialTheme.typography.titleLarge,
                fontSize = 18.sp
            )
        }

        val dotColor = when (enginePhase) {
            EnginePhase.READY -> StudioColors.StatusReadyGreen
            EnginePhase.DOWNLOADING, EnginePhase.LOADING, EnginePhase.MISSING_MODELS -> StudioColors.StatusWorkAmber
            else -> StudioColors.DangerRed
        }

        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(99.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(99.dp))
                .pointerInput(Unit) { detectTapGestures { onBadgeClick() } }
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = badgeText,
                style = MaterialTheme.typography.bodySmall,
                color = StudioColors.TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Dual-layer Interactive Waveform Scrubber (`#4a5268` base bars + `#5eead4` played bars + white playhead).
 * Exact Jetpack Compose Canvas port of `renderWaveLayers()` and `drawWave()` in `extension/studio.js`.
 */
@Composable
fun WaveformScrubberCanvas(
    peaks: FloatArray,
    progressFraction: Float,
    enabled: Boolean,
    onSeekFraction: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(60.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(StudioColors.PanelElevated)
            .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(10.dp))
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures { offset ->
                    if (size.width > 0) {
                        onSeekFraction((offset.x / size.width).coerceIn(0f, 1f))
                    }
                }
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    if (size.width > 0) {
                        onSeekFraction((change.position.x / size.width).coerceIn(0f, 1f))
                    }
                }
            }
            .padding(horizontal = 4.dp, vertical = 4.dp)
    ) {
        val w = size.width
        val h = size.height
        val playX = (progressFraction.coerceIn(0f, 1f)) * w

        if (peaks.isEmpty() || !enabled) {
            drawRect(
                color = StudioColors.WaveUnplayed,
                topLeft = Offset(0f, h / 2f - 1.dp.toPx()),
                size = Size(w, 2.dp.toPx())
            )
            return@Canvas
        }

        val barWidth = 2.dp.toPx().coerceAtLeast(1f)
        val gap = 1.dp.toPx().coerceAtLeast(1f)
        val totalBars = max(1, (w / (barWidth + gap)).toInt())

        for (i in 0 until totalBars) {
            val x = i * (barWidth + gap)
            val peakIdx = min(peaks.lastIndex, (i.toFloat() / totalBars * peaks.size).toInt())
            val amp = peaks[peakIdx].coerceIn(0f, 1f)
            val barH = max(3.dp.toPx(), amp * (h - 6.dp.toPx()))
            val y = (h - barH) / 2f
            val color = if (x <= playX) StudioColors.AccentTeal else StudioColors.WaveUnplayed
            drawRoundRect(
                color = color,
                topLeft = Offset(x, y),
                size = Size(barWidth, barH),
                cornerRadius = CornerRadius(1.dp.toPx(), 1.dp.toPx())
            )
        }

        if (enabled && progressFraction > 0f) {
            drawRect(
                color = Color.White,
                topLeft = Offset(min(w - 2.dp.toPx(), playX), 0f),
                size = Size(2.dp.toPx(), h)
            )
        }
    }
}

/**
 * Persistent Bottom Player, Waveform, Export (`Save WAV`, `Save MP3`, `Share`) & Progress Footer
 * matching `<footer class="player">` in `extension/studio.html`.
 */
@Composable
fun PersistentPlayerFooter(
    hasLoadedAudio: Boolean,
    isPlaying: Boolean,
    currentSecFormatted: String,
    totalSecFormatted: String,
    progressFraction: Float,
    peaks: FloatArray,
    isBusy: Boolean,
    generationProgressPct: Int,
    statusMessage: String,
    isStatusError: Boolean,
    onPlayPause: () -> Unit,
    onSeekFraction: (Float) -> Unit,
    onSaveWav: () -> Unit,
    onSaveMp3: () -> Unit,
    onShareAudio: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.Panel)
            .border(1.dp, StudioColors.BorderLine)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledIconButton(
                onClick = onPlayPause,
                enabled = hasLoadedAudio,
                modifier = Modifier.size(42.dp),
                shape = CircleShape,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = StudioColors.AccentViolet,
                    disabledContainerColor = StudioColors.PanelElevated
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Text(
                text = "$currentSecFormatted / $totalSecFormatted",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.width(76.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            WaveformScrubberCanvas(
                peaks = peaks,
                progressFraction = progressFraction,
                enabled = hasLoadedAudio,
                onSeekFraction = onSeekFraction,
                modifier = Modifier.weight(1f)
            )
        }

        if (hasLoadedAudio) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onSaveWav,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(9.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioColors.TextPrimary)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save WAV", fontSize = 12.5.sp)
                }
                OutlinedButton(
                    onClick = onSaveMp3,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(9.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioColors.TextPrimary)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save MP3", fontSize = 12.5.sp)
                }
                OutlinedButton(
                    onClick = onShareAudio,
                    shape = RoundedCornerShape(9.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioColors.AccentTeal)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share Audio", modifier = Modifier.size(16.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(StudioColors.PanelElevated)
        ) {
            val barWidthFraction = if (isBusy) (generationProgressPct / 100f).coerceIn(0.04f, 1f) else 0f
            if (barWidthFraction > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(barWidthFraction)
                        .fillMaxHeight()
                        .background(
                            Brush.horizontalGradient(
                                listOf(StudioColors.AccentViolet, StudioColors.AccentTeal)
                            )
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(5.dp))

        Text(
            text = statusMessage,
            style = MaterialTheme.typography.bodySmall,
            color = if (isStatusError) StudioColors.DangerRed else StudioColors.TextMuted,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
