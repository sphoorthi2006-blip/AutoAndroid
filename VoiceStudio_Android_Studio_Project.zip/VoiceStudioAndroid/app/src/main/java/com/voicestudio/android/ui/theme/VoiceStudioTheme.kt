package com.voicestudio.android.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Exact VoiceStudio Dark-First Palette from `extension/studio.css`
 * (`--bg:#0e1015`, `--panel:#161922`, `--panel2:#1d212c`, `--line:#2a3040`,
 *  `--text:#e8eaf2`, `--muted:#8b93a7`, `--acc:#7c6cff`, `--acc2:#5eead4`, `--bad:#ff6b7a`).
 */
object StudioColors {
    val Background = Color(0xFF0E1015)
    val Panel = Color(0xFF161922)
    val PanelElevated = Color(0xFF1D212C)
    val BorderLine = Color(0xFF2A3040)
    val TextPrimary = Color(0xFFE8EAF2)
    val TextMuted = Color(0xFF8B93A7)
    val AccentViolet = Color(0xFF7C6CFF)
    val AccentIndigo = Color(0xFF5A8BFF)
    val AccentTeal = Color(0xFF5EEAD4)
    val PresetActiveSurface = Color(0xFF18262B)
    val WaveUnplayed = Color(0xFF4A5268)
    val StatusReadyGreen = Color(0xFF4ADE80)
    val StatusWorkAmber = Color(0xFFFBBF24)
    val DangerRed = Color(0xFFFF6B7A)
}

private val VoiceStudioDarkColorScheme = darkColorScheme(
    primary = StudioColors.AccentViolet,
    onPrimary = Color.White,
    secondary = StudioColors.AccentTeal,
    onSecondary = Color(0xFF071318),
    tertiary = StudioColors.AccentIndigo,
    background = StudioColors.Background,
    onBackground = StudioColors.TextPrimary,
    surface = StudioColors.Panel,
    onSurface = StudioColors.TextPrimary,
    surfaceVariant = StudioColors.PanelElevated,
    onSurfaceVariant = StudioColors.TextMuted,
    outline = StudioColors.BorderLine,
    error = StudioColors.DangerRed,
    onError = Color.White
)

private val VoiceStudioTypography = Typography(
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        color = StudioColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 21.sp,
        color = StudioColors.TextPrimary
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.5.sp,
        letterSpacing = 0.7.sp,
        color = StudioColors.TextMuted
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 24.sp,
        color = StudioColors.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.5.sp,
        lineHeight = 19.sp,
        color = StudioColors.TextPrimary
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = StudioColors.TextMuted
    )
)

@Composable
fun VoiceStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VoiceStudioDarkColorScheme,
        typography = VoiceStudioTypography,
        content = content
    )
}
