package com.voicestudio.android

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.voicestudio.android.ui.components.PersistentPlayerFooter
import com.voicestudio.android.ui.components.StudioTopHeader
import com.voicestudio.android.ui.screens.ModelManagementAndSettingsScreen
import com.voicestudio.android.ui.screens.MyVoiceAndAccentScreen
import com.voicestudio.android.ui.screens.ProjectsHistoryScreen
import com.voicestudio.android.ui.screens.StudioScreen
import com.voicestudio.android.ui.screens.VoicesAndMixerScreen
import com.voicestudio.android.ui.theme.StudioColors
import com.voicestudio.android.ui.theme.VoiceStudioTheme
import com.voicestudio.android.viewmodel.StudioViewModel

enum class StudioTab(val label: String) {
    STUDIO("Studio"),
    VOICES("Voices & Mix"),
    MY_VOICE("My Voice"),
    HISTORY("Projects"),
    MODELS("Models")
}

class MainActivity : ComponentActivity() {

    private val viewModel: StudioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VoiceStudioTheme {
                VoiceStudioAppRoot(viewModel = viewModel)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        viewModel.flushPrefsNow()
    }
}

@Composable
fun VoiceStudioAppRoot(viewModel: StudioViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var currentTab by rememberSaveable { mutableStateOf(StudioTab.STUDIO) }

    // SAF Launcher for .txt script import
    val openTxtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.importTxtFile(it) }
    }

    // SAF Launcher for WAV export
    val createWavLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("audio/wav")
    ) { uri: Uri? ->
        uri?.let { viewModel.exportAudioToUri(it, "wav") }
    }

    // SAF Launcher for MP3 export
    val createMp3Launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("audio/mpeg")
    ) { uri: Uri? ->
        uri?.let { viewModel.exportAudioToUri(it, "mp3") }
    }

    // SAF Launcher for Reference Voice WAV import
    val importRefVoiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.importReferenceVoiceUri(it) }
    }

    // SAF Launcher for Offline Model (.onnx / .bin / .zip) import
    val importModelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val fileName = queryDisplayName(context.contentResolver, it)
            viewModel.importModelFileUri(it, fileName)
        }
    }

    // Runtime Microphone Permission Launcher
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted) {
            viewModel.startMicRecording()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioColors.Background),
        containerColor = StudioColors.Background,
        topBar = {
            StudioTopHeader(
                enginePhase = state.enginePhase,
                badgeText = state.engineBadgeText,
                onBadgeClick = { currentTab = StudioTab.MODELS }
            )
        },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                val playFraction = if (state.totalAudioDurationSec > 0f) {
                    (state.currentPlayheadSec / state.totalAudioDurationSec).coerceIn(0f, 1f)
                } else 0f

                PersistentPlayerFooter(
                    hasLoadedAudio = state.hasLoadedAudio,
                    isPlaying = state.isPlayingAudio,
                    currentSecFormatted = viewModel.formatDuration(state.currentPlayheadSec),
                    totalSecFormatted = viewModel.formatDuration(state.totalAudioDurationSec),
                    progressFraction = playFraction,
                    peaks = state.waveformPeaks,
                    isBusy = state.isBusyGenerating,
                    generationProgressPct = state.progressPct,
                    statusMessage = state.statusMessage,
                    isStatusError = state.isStatusError,
                    onPlayPause = viewModel::togglePlayPause,
                    onSeekFraction = viewModel::seekAudioToFraction,
                    onSaveWav = { createWavLauncher.launch(viewModel.suggestedExportFileName("wav")) },
                    onSaveMp3 = { createMp3Launcher.launch(viewModel.suggestedExportFileName("mp3")) },
                    onShareAudio = { viewModel.shareCurrentAudio("wav") }
                )

                NavigationBar(
                    containerColor = StudioColors.Panel,
                    contentColor = StudioColors.TextPrimary
                ) {
                    StudioTab.entries.forEach { tab ->
                        val icon = when (tab) {
                            StudioTab.STUDIO -> Icons.Default.EditNote
                            StudioTab.VOICES -> Icons.Default.RecordVoiceOver
                            StudioTab.MY_VOICE -> Icons.Default.Mic
                            StudioTab.HISTORY -> Icons.Default.History
                            StudioTab.MODELS -> Icons.Default.Settings
                        }
                        NavigationBarItem(
                            selected = currentTab == tab,
                            onClick = { currentTab = tab },
                            icon = { Icon(icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = StudioColors.AccentTeal,
                                selectedTextColor = StudioColors.AccentTeal,
                                indicatorColor = StudioColors.PresetActiveSurface,
                                unselectedIconColor = StudioColors.TextMuted,
                                unselectedTextColor = StudioColors.TextMuted
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                StudioTab.STUDIO -> StudioScreen(
                    state = state,
                    onScriptChange = viewModel::onScriptChanged,
                    onOpenTxtClick = { openTxtLauncher.launch(arrayOf("text/plain", "text/*")) },
                    onInsertPauseClick = { viewModel.insertPauseTagAtEndOrCursor("1") },
                    onClearScriptClick = viewModel::clearScript,
                    onTeluguSampleClick = viewModel::loadTeluguSampleSentence,
                    onStyleChange = viewModel::setConversationStyle,
                    onSpeedChange = viewModel::setSpeedPercent,
                    onPresetClick = { idx ->
                        state.presets.getOrNull(idx)?.let { viewModel.applyPreset(it) }
                    },
                    onPreviewClick = { viewModel.runSynthesis(isPreview = true) },
                    onGenerateClick = { viewModel.runSynthesis(isPreview = false) },
                    onCancelClick = viewModel::cancelGeneration,
                    onNavigateToVoices = { currentTab = StudioTab.VOICES },
                    onNavigateToMyVoice = { currentTab = StudioTab.MY_VOICE }
                )

                StudioTab.VOICES -> VoicesAndMixerScreen(
                    state = state,
                    onSelectGroup = viewModel::selectLanguageGroup,
                    onSelectGender = viewModel::selectGenderFilter,
                    onSelectLibraryVoice = viewModel::selectLibraryVoice,
                    onStepVoice = viewModel::stepLibraryVoice,
                    onHearCurrentVoice = viewModel::auditionCurrentLibraryVoice,
                    onToggleFavorite = viewModel::toggleFavoriteCurrentVoice,
                    onShuffleVoice = viewModel::shuffleLibraryVoice,
                    onCustomMainVoiceChange = viewModel::setMainVoiceCustom,
                    onCustomBlendVoiceChange = viewModel::setBlendVoiceCustom,
                    onCustomBlendPctChange = viewModel::setBlendPercentCustom,
                    onAuditionSingleBaseVoice = viewModel::auditionSingleBaseVoice
                )

                StudioTab.MY_VOICE -> MyVoiceAndAccentScreen(
                    state = state,
                    onStartRecordingClick = {
                        val hasPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (hasPerm) {
                            viewModel.startMicRecording()
                        } else {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onStopRecordingClick = viewModel::stopMicRecording,
                    onImportWavClick = { importRefVoiceLauncher.launch(arrayOf("audio/*")) },
                    onTrimRangeChange = viewModel::updateCandidateTrim,
                    onPreviewTrimmedClick = viewModel::previewTrimmedCandidateRecording,
                    onProfileNameChange = viewModel::updateCandidateProfileName,
                    onConsentCheckedChange = viewModel::updateCandidateConsent,
                    onSaveProfileClick = viewModel::savePersonalVoiceProfile,
                    onSelectProfile = viewModel::selectPersonalVoiceForGeneration,
                    onRenameProfile = viewModel::renamePersonalVoiceProfile,
                    onDeleteProfile = viewModel::deletePersonalVoiceProfile,
                    onSelectTargetAccent = viewModel::selectTargetAccent
                )

                StudioTab.HISTORY -> ProjectsHistoryScreen(
                    state = state,
                    onPlayProject = viewModel::playSavedProject,
                    onLoadScriptIntoStudio = { scriptText ->
                        viewModel.onScriptChanged(scriptText)
                        currentTab = StudioTab.STUDIO
                    },
                    onRenameProject = viewModel::renameSavedProject,
                    onDeleteProject = viewModel::deleteSavedProject
                )

                StudioTab.MODELS -> ModelManagementAndSettingsScreen(
                    state = state,
                    onDownloadPack = viewModel::downloadModelPack,
                    onDeletePack = viewModel::deleteModelPack,
                    onManualImportFileClick = { importModelLauncher.launch(arrayOf("*/*")) }
                )
            }
        }
    }
}

private fun queryDisplayName(resolver: android.content.ContentResolver, uri: Uri): String? {
    var cursor: Cursor? = null
    return try {
        cursor = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        if (cursor != null && cursor.moveToFirst()) {
            cursor.getString(0)
        } else null
    } catch (_: Exception) {
        null
    } finally {
        cursor?.close()
    }
}
