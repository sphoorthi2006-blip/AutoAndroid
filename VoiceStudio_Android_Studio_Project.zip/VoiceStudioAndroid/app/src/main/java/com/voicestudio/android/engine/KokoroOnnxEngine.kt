package com.voicestudio.android.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import com.voicestudio.android.domain.VoiceStudioCatalog
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.util.zip.ZipInputStream
import kotlin.math.min

/**
 * Production On-Device Kokoro-82M v1.0 ONNX Inference Engine for Android.
 *
 * - Loads `kokoro-v1.0.onnx` (Opset 20) via `onnxruntime-android`
 * - Parses `voices-v1.0.bin` (`.npz` archive of 54 `.npy` float32 tensors shaped `(510, 1, 256)`)
 * - Performs linear style vector blending `(1.0f - blend) * voiceA + blend * voiceB`
 * - Maps IPA phonemes to the exact 178-entry vocabulary from `hexgrad/Kokoro-82M/config.json`
 * - Wraps tokens with `BOS = 0` and `EOS = 0` (`int64[1, N+2]`) and executes on CPU big cores
 */
class KokoroOnnxEngine(
    private val phonemizer: OfflinePhonemizer = MultilingualG2pPhonemizer()
) : AutoCloseable {

    companion object {
        const val SAMPLE_RATE = 24000
        const val MAX_PHONEME_TOKENS = 510
        const val STYLE_DIM = 256
        const val EXPECTED_NPY_DATA_BYTES = MAX_PHONEME_TOKENS * STYLE_DIM * 4 // 522,240 bytes

        // Exact 114 mapped entries from hexgrad/Kokoro-82M config.json (n_token = 178)
        val VOCAB: Map<Char, Long> = mapOf(
            ';' to 1L, ':' to 2L, ',' to 3L, '.' to 4L, '!' to 5L, '?' to 6L,
            '\u2014' to 9L, '\u2026' to 10L, '"' to 11L, '(' to 12L, ')' to 13L,
            '\u201C' to 14L, '\u201D' to 15L, ' ' to 16L, '\u0303' to 17L,
            '\u02A3' to 18L, '\u02A5' to 19L, '\u02A6' to 20L, '\u02A8' to 21L,
            '\u1D5D' to 22L, '\uAB67' to 23L, 'A' to 24L, 'I' to 25L, 'O' to 31L,
            'Q' to 33L, 'S' to 35L, 'T' to 36L, 'W' to 39L, 'Y' to 41L, '\u1D4A' to 42L,
            'a' to 43L, 'b' to 44L, 'c' to 45L, 'd' to 46L, 'e' to 47L, 'f' to 48L,
            'h' to 50L, 'i' to 51L, 'j' to 52L, 'k' to 53L, 'l' to 54L, 'm' to 55L,
            'n' to 56L, 'o' to 57L, 'p' to 58L, 'q' to 59L, 'r' to 60L, 's' to 61L,
            't' to 62L, 'u' to 63L, 'v' to 64L, 'w' to 65L, 'x' to 66L, 'y' to 67L,
            'z' to 68L, '\u0251' to 69L, '\u0250' to 70L, '\u0252' to 71L, '\u00E6' to 72L,
            '\u03B2' to 75L, '\u0254' to 76L, '\u0255' to 77L, '\u00E7' to 78L, '\u0256' to 80L,
            '\u00F0' to 81L, '\u02A4' to 82L, '\u0259' to 83L, '\u025A' to 85L, '\u025B' to 86L,
            '\u025C' to 87L, '\u025F' to 90L, '\u0261' to 92L, '\u0265' to 99L, '\u0268' to 101L,
            '\u026A' to 102L, '\u029D' to 103L, '\u026F' to 110L, '\u0270' to 111L, '\u014B' to 112L,
            '\u0273' to 113L, '\u0272' to 114L, '\u0274' to 115L, '\u00F8' to 116L, '\u0278' to 118L,
            '\u03B8' to 119L, '\u0153' to 120L, '\u0279' to 123L, '\u027E' to 125L, '\u027B' to 126L,
            '\u0281' to 128L, '\u027D' to 129L, '\u0282' to 130L, '\u0283' to 131L, '\u0288' to 132L,
            '\u02A7' to 133L, '\u028A' to 135L, '\u028B' to 136L, '\u028C' to 138L, '\u0263' to 139L,
            '\u0264' to 140L, '\u03C7' to 142L, '\u028E' to 143L, '\u0292' to 147L, '\u0294' to 148L,
            '\u02C8' to 156L, '\u02CC' to 157L, '\u02D0' to 158L, '\u02B0' to 162L, '\u02B2' to 164L,
            '\u2193' to 169L, '\u2192' to 171L, '\u2197' to 172L, '\u2198' to 173L, '\u1D7B' to 177L
        )

        fun tokenizeIpa(ipa: String): LongArray {
            val contentIds = ArrayList<Long>(min(ipa.length, MAX_PHONEME_TOKENS))
            for (ch in ipa) {
                val id = VOCAB[ch] ?: continue
                contentIds.add(id)
                if (contentIds.size >= MAX_PHONEME_TOKENS) break
            }
            if (contentIds.isEmpty()) {
                contentIds.add(16L) // single space fallback token
            }
            val padded = LongArray(contentIds.size + 2)
            padded[0] = 0L
            for (i in contentIds.indices) {
                padded[i + 1] = contentIds[i]
            }
            padded[padded.lastIndex] = 0L
            return padded
        }

        fun parseNpyFloat32(npyBytes: ByteArray): FloatArray {
            require(npyBytes.size >= 10 && npyBytes[0] == 0x93.toByte() && npyBytes[1] == 'N'.code.toByte()) {
                "Invalid .npy header magic"
            }
            val major = npyBytes[6].toInt() and 0xFF
            val headerLen = if (major <= 1) {
                (npyBytes[8].toInt() and 0xFF) or ((npyBytes[9].toInt() and 0xFF) shl 8)
            } else {
                ByteBuffer.wrap(npyBytes, 8, 4).order(ByteOrder.LITTLE_ENDIAN).int
            }
            val dataOffset = (if (major <= 1) 10 else 12) + headerLen
            val payloadBytes = npyBytes.size - dataOffset
            require(payloadBytes >= EXPECTED_NPY_DATA_BYTES) {
                "Unexpected voice .npy payload size: $payloadBytes"
            }
            val out = FloatArray(MAX_PHONEME_TOKENS * STYLE_DIM)
            ByteBuffer.wrap(npyBytes, dataOffset, EXPECTED_NPY_DATA_BYTES)
                .order(ByteOrder.LITTLE_ENDIAN)
                .asFloatBuffer()
                .get(out)
            return out
        }

        fun loadVoicesArchive(inputStream: InputStream): Map<String, FloatArray> {
            val supportedPrefixes = setOf('a', 'b', 'h', 'e', 'f', 'i', 'p')
            val voices = HashMap<String, FloatArray>(48)
            ZipInputStream(inputStream.buffered()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (name.endsWith(".npy")) {
                        val voiceId = name.removeSuffix(".npy").substringAfterLast('/')
                        if (voiceId.length > 3 &&
                            voiceId[0] in supportedPrefixes &&
                            (voiceId[1] == 'f' || voiceId[1] == 'm') &&
                            voiceId[2] == '_'
                        ) {
                            voices[voiceId] = parseNpyFloat32(zis.readBytes())
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            return voices
        }
    }

    private var ortEnv: OrtEnvironment? = null
    private var ortSession: OrtSession? = null
    private var voiceTensors: Map<String, FloatArray> = emptyMap()
    private var tokensInputName: String = "tokens"
    private val sessionLock = Any()

    val isLoaded: Boolean
        get() = synchronized(sessionLock) { ortSession != null && voiceTensors.isNotEmpty() }

    fun load(modelFile: File, voicesFile: File) {
        synchronized(sessionLock) {
            close()
            val env = OrtEnvironment.getEnvironment()
            val cpuCores = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(if (cpuCores > 4) cpuCores - 1 else cpuCores)
                setInterOpNumThreads(1)
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                setMemoryPatternOptimization(true)
                setCPUArenaAllocator(true)
                try {
                    addConfigEntry("session.intra_op.allow_spinning", "0")
                } catch (_: Exception) {
                }
            }
            val session = env.createSession(modelFile.absolutePath, opts)
            tokensInputName = session.inputNames.firstOrNull { it == "input_ids" || it == "tokens" }
                ?: session.inputNames.first()
            val loadedVoices = FileInputStream(voicesFile).use { loadVoicesArchive(it) }

            ortEnv = env
            ortSession = session
            voiceTensors = loadedVoices
        }
    }

    fun availableVoices(): List<String> = synchronized(sessionLock) {
        if (voiceTensors.isNotEmpty()) voiceTensors.keys.sorted() else VoiceStudioCatalog.KOKORO_BASE_VOICES
    }

    fun sliceStyleVector(
        voice: String,
        blendVoice: String?,
        blendRatio: Float,
        unpaddedTokenLen: Int
    ): FloatArray {
        val primary = voiceTensors[voice] ?: voiceTensors.values.firstOrNull()
            ?: error("Kokoro voice tensors are not loaded.")
        val rowIdx = unpaddedTokenLen.coerceIn(0, MAX_PHONEME_TOKENS - 1)
        val offset = rowIdx * STYLE_DIM
        val out = FloatArray(STYLE_DIM)
        val secondary = if (!blendVoice.isNullOrBlank() && blendVoice != voice && blendRatio > 0.01f) {
            voiceTensors[blendVoice]
        } else null

        if (secondary == null) {
            System.arraycopy(primary, offset, out, 0, STYLE_DIM)
        } else {
            val wA = 1.0f - blendRatio
            val wB = blendRatio
            for (i in 0 until STYLE_DIM) {
                out[i] = wA * primary[offset + i] + wB * secondary[offset + i]
            }
        }
        return out
    }

    fun synthesizeChunk(
        chunkText: String,
        voice: String,
        blendVoice: String? = null,
        blendRatio: Float = 0f,
        speed: Float = 1.0f,
        overridePhonemeLang: String? = null
    ): FloatArray = synchronized(sessionLock) {
        val env = ortEnv ?: error("ONNX Environment not initialized")
        val session = ortSession ?: error("Kokoro ONNX model is not loaded. Install or import kokoro-v1.0.onnx in Model Management.")

        val langCode = overridePhonemeLang ?: when (voice.firstOrNull()) {
            'b' -> "en-gb"
            'h' -> "hi"
            'e' -> "es"
            'f' -> "fr-fr"
            'i' -> "it"
            'p' -> "pt-br"
            else -> "en-us"
        }
        val ipa = phonemizer.phonemize(chunkText, langCode)
        val paddedTokens = tokenizeIpa(ipa)
        val unpaddedLen = (paddedTokens.size - 2).coerceAtLeast(1)
        val styleSlice = sliceStyleVector(voice, blendVoice, blendRatio, unpaddedLen)

        val tokensTensor = OnnxTensor.createTensor(
            env,
            LongBuffer.wrap(paddedTokens),
            longArrayOf(1L, paddedTokens.size.toLong())
        )
        val styleTensor = OnnxTensor.createTensor(
            env,
            FloatBuffer.wrap(styleSlice),
            longArrayOf(1L, STYLE_DIM.toLong())
        )
        val speedTensor = OnnxTensor.createTensor(
            env,
            FloatBuffer.wrap(floatArrayOf(speed)),
            longArrayOf(1L)
        )

        tokensTensor.use { tTok ->
            styleTensor.use { tSty ->
                speedTensor.use { tSpd ->
                    val inputs = mapOf(
                        tokensInputName to tTok,
                        "style" to tSty,
                        "speed" to tSpd
                    )
                    session.run(inputs).use { results ->
                        val rawValue = results[0].value
                        return when (rawValue) {
                            is Array<*> -> (rawValue[0] as FloatArray)
                            is FloatArray -> rawValue
                            else -> {
                                val fb = (results[0] as OnnxTensor).floatBuffer
                                FloatArray(fb.remaining()).also { fb.get(it) }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun close() {
        synchronized(sessionLock) {
            try {
                ortSession?.close()
            } catch (_: Exception) {
            }
            ortSession = null
            voiceTensors = emptyMap()
        }
    }
}
