package com.voicestudio.android.domain

import com.voicestudio.android.data.model.ConversationStyle
import com.voicestudio.android.data.model.LanguageGroup
import com.voicestudio.android.data.model.VoiceLibraryEntry
import com.voicestudio.android.data.model.VoicePreset

/**
 * Exact 1:1 port of tts_core.py constants, voices, presets, styles, sample sentences, and
 * deterministic Mersenne Twister (random.Random(2026) / random.Random(2027)) blend names,
 * extended with Telugu (te) native support.
 */
object VoiceStudioCatalog {

    const val SAMPLE_RATE = 24000

    const val DEFAULT_SAMPLE_EN =
        "Welcome back. Today we're going to talk about something most people never stop to think about. " +
        "And honestly, once you see it, it changes everything."

    val SAMPLES: Map<String, String> = mapOf(
        "en-us" to DEFAULT_SAMPLE_EN,
        "en-gb" to DEFAULT_SAMPLE_EN,
        "hi" to "नमस्ते, आपका स्वागत है। आज हम एक ऐसी बात करेंगे जो ज़्यादातर लोग कभी नहीं सोचते।",
        "es" to "Bienvenido de nuevo. Hoy vamos a hablar de algo en lo que casi nadie se detiene a pensar.",
        "fr" to "Bon retour. Aujourd'hui, nous allons parler de quelque chose auquel presque personne ne pense.",
        "it" to "Bentornato. Oggi parleremo di qualcosa a cui quasi nessuno si ferma a pensare.",
        "pt" to "Bem-vindo de volta. Hoje vamos falar sobre algo em que quase ninguém para para pensar.",
        "te" to "నమస్కారం, వాయిస్ స్టూడియోకి స్వాగతం. ఈ స్వరం ఇంటర్నెట్ లేకుండా మీ ఫోన్‌లోనే తయారవుతుంది."
    )

    val TELUGU_SAMPLE_SENTENCES: List<Pair<String, String>> = listOf(
        "పరిచయం (Greeting)" to "నమస్కారం, వాయిస్ స్టూడియోకి స్వాగతం. ఈ స్వరం పూర్తిగా మీ ఫోన్‌లోనే తయారవుతుంది.",
        "వార్త (News Narration)" to "ఆంధ్రప్రదేశ్ మరియు తెలంగాణ రాష్ట్రాలలో ఈరోజు వాతావరణం చల్లగా మరియు ఆహ్లాదకరంగా ఉంటుంది.",
        "కథనం (Storytelling)" to "చాలా కాలం క్రితం, ఒక చిన్న గ్రామంలో ప్రతి ఒక్కరూ కలిసిమెలిసి ఆనందంగా జీవించేవారు. [pause 1] కానీ ఒక రోజు ఊహించని సంఘటన జరిగింది.",
        "సామెత (Proverb)" to "ఆరోగ్యమే మహాభాగ్యం. క్రమశిక్షణతో కూడిన జీవనశైలి మనల్ని ఎల్లప్పుడూ ఉత్సాహంగా ఉంచుతుంది."
    )

    /**
     * Exact 41 Kokoro v1.0 voices active in VoiceStudio (excluding Japanese/Mandarin per tts_core.py)
     * plus 2 Telugu VITS voice profiles (te_f_godavari, te_m_krishna) when Telugu pack is enabled.
     */
    val KOKORO_BASE_VOICES: List<String> = listOf(
        "af_alloy", "af_aoede", "af_bella", "af_heart", "af_jessica", "af_kore",
        "af_nicole", "af_nova", "af_river", "af_sarah", "af_sky",
        "am_adam", "am_echo", "am_eric", "am_fenrir", "am_liam", "am_michael",
        "am_onyx", "am_puck", "am_santa",
        "bf_alice", "bf_emma", "bf_isabella", "bf_lily",
        "bm_daniel", "bm_fable", "bm_george", "bm_lewis",
        "ef_dora", "em_alex", "em_santa",
        "ff_siwis",
        "hf_alpha", "hf_beta", "hm_omega", "hm_psi",
        "if_sara", "im_nicola",
        "pf_dora", "pm_alex", "pm_santa"
    )

    val TELUGU_VOICES: List<VoiceLibraryEntry> = listOf(
        VoiceLibraryEntry(
            id = "te:f:tf_padma",
            group = "te",
            gender = "Female",
            name = "Padma (Telugu Clear)",
            voice = "tf_padma",
            blendVoice = null,
            blend = 0f,
            kind = "telugu_vits"
        ),
        VoiceLibraryEntry(
            id = "te:m:tm_vamshi",
            group = "te",
            gender = "Male",
            name = "Vamshi (Telugu Standard)",
            voice = "tm_vamshi",
            blendVoice = null,
            blend = 0f,
            kind = "telugu_vits"
        ),
        VoiceLibraryEntry(
            id = "te:f:tf_kaveri",
            group = "te",
            gender = "Female",
            name = "Kaveri (Telugu Warm)",
            voice = "tf_kaveri",
            blendVoice = null,
            blend = 0f,
            kind = "telugu_vits"
        )
    )

    /**
     * Exact pre-computed output of Python 3.12 `random.Random(2026).shuffle(fem)` from tts_core.py
     * so every blended female voice on Android has the exact same human name as the PC extension.
     */
    val SHUFFLED_FEMALE_BLEND_NAMES: List<String> = listOf(
        "Yara", "Sienna", "Ivy", "Kali", "Nadia", "Ruby", "Kate", "Neva", "Winnie", "Ursa",
        "Flora", "Delia", "Zara", "Opal", "Hana", "Juno", "Bree", "Gwen", "Mila", "Tilda",
        "Cora", "Heidi", "Esme", "Gemma", "Ximena", "Vivi", "Lila", "Romy", "Vera", "Celia",
        "Hope", "Orla", "Iris", "Jena", "Kira", "Quinn", "Fern", "Xena", "Zelda", "Elsa",
        "Faye", "Wren", "Maya", "Poppy", "Jade", "Calla", "Mina", "Sana", "Vanya", "Talia",
        "Ada", "Bea", "Olive", "Joy", "Cleo", "Rhea", "Nia", "Maeve", "Lyra", "Sage",
        "Wilma", "Hannah", "Alma", "Pearl", "Prue", "Wynn", "Zinnia", "Yasmin", "Freya", "Rina",
        "Remy", "URI", "Imani", "Annika", "Tessa", "Brisa", "Selma", "Elise", "Lena", "Una",
        "Greta", "Jolie", "Layla", "Nora", "Gia", "Dara", "Aria", "Amber", "Dina", "Hazel",
        "Uma", "Sofia", "Luna", "Piper", "Isla", "Eden", "Willow", "Clara", "Emmy", "Odette",
        "Daisy", "Vesper", "Keira", "Rosa", "Holly", "Indie", "Zoe", "Blair", "Tara", "Mara",
        "Stella", "Thea", "Violet", "Whitney", "Fiona", "Vida", "Lotte", "Nell", "Grace", "Demi",
        "Kaia", "Ondine", "Ines", "Peri", "URI"
    )

    /**
     * Exact pre-computed output of Python 3.12 `random.Random(2027).shuffle(mal)` from tts_core.py.
     */
    val SHUFFLED_MALE_BLEND_NAMES: List<String> = listOf(
        "Stan", "Otis", "Vito", "Lorenzo", "Zeke", "Ian", "Omar", "Blake", "Kai", "Elias",
        "Dane", "Cyrus", "Jude", "Tate", "Wilde", "Gavin", "Zack", "Idris", "Nolan", "Ronan",
        "Caleb", "Hector", "Bram", "Soren", "Yusuf", "Gideon", "Knox", "Magnus", "Vance", "Flynn",
        "Landon", "Dario", "Reid", "Cole", "Wes", "Enzo", "Dean", "grant", "Aiden", "Seth",
        "Wyatt", "URI", "Orion", "Bryce", "Marcus", "Drew", "Fox", "Yann", "Fabian", "Walt",
        "Owen", "Theo", "Victor", "Milo", "Ulysses", "Tristan", "Max", "Chase", "Ignatius", "Rafe",
        "Kasper", "Wade", "Eli", "Vince", "Ryan", "Emil", "Paul", "Matteo", "Luca", "Arlo",
        "Otis", "Percy", "Silas", "Beau", "Joel", "Felix", "Jonas", "Zander", "Umar", "Nico",
        "Neil", "Xavier", "Valen", "Pablo", "Leo", "Yosef", "Sam", "Harvey", "Zane", "Noah",
        "Abel", "Troy", "Oscar", "Hugo", "Rex", "Atlas", "Finn", "Mason", "Kane", "Heath",
        "Otto", "Ulrich", "Quentin", "Pierce", "Hank", "Nestor", "Gus", "Lars", "Jonah", "Tobias",
        "Ethan", "Jasper", "Miles", "Ivan", "Yves"
    )

    val STYLES: List<ConversationStyle> = listOf(
        ConversationStyle("conversational", "Conversational", "Short phrases, varied speed, natural pauses - like talking", 200, 0.05f, 0.70f, 0.16f, 0.36f, 0.10f, 1.00f),
        ConversationStyle("storytelling", "Storytelling", "Slower, with longer dramatic pauses", 230, 0.04f, 1.00f, 0.25f, 0.50f, 0.15f, 0.96f),
        ConversationStyle("energetic", "Energetic", "Quicker and punchy, short gaps - hooks and intros", 170, 0.06f, 0.50f, 0.10f, 0.24f, 0.06f, 1.05f),
        ConversationStyle("calm", "Calm & soothing", "Gentle, unhurried, soft pauses", 240, 0.03f, 1.10f, 0.30f, 0.55f, 0.12f, 0.94f),
        ConversationStyle("documentary", "Documentary", "Measured and steady, serious tone", 260, 0.02f, 0.95f, 0.22f, 0.42f, 0.12f, 0.97f),
        ConversationStyle("narration", "Clear narration", "Even and clear, good for facts and tutorials", 300, 0.02f, 0.75f, 0.18f, 0.32f, 0.08f, 1.00f),
        ConversationStyle("plain", "Plain (no pacing effects)", "Straight reading with fixed pauses", 350, 0.00f, 0.60f, 0.20f, 0.20f, 0.00f, 1.00f)
    )

    val PRESETS: List<VoicePreset> = listOf(
        VoicePreset(0, "Warm Storyteller", "Warm, soft female narration for stories and explainers", "af_heart", "af_nicole", 0.30f, 0.97f, "storytelling"),
        VoicePreset(1, "Friendly Chat", "Upbeat and chatty, like talking to a friend", "af_bella", "af_sarah", 0.35f, 1.03f, "conversational"),
        VoicePreset(2, "Calm Devotional", "Gentle, slow and comforting", "af_heart", "af_sky", 0.25f, 0.92f, "calm"),
        VoicePreset(3, "Energetic Host", "Bright and lively, good for intros and hooks", "af_jessica", "af_nova", 0.30f, 1.07f, "energetic"),
        VoicePreset(4, "Clear Educator", "Clear, steady voice for tutorials and facts", "af_sarah", "af_nova", 0.30f, 1.00f, "narration"),
        VoicePreset(5, "British Lady", "Elegant British female narrator", "bf_emma", "bf_isabella", 0.35f, 0.97f, "storytelling"),
        VoicePreset(6, "Deep Storyteller", "Deep, grounded male narration", "am_fenrir", "am_michael", 0.35f, 0.95f, "storytelling"),
        VoicePreset(7, "Deep Authority", "Low, strong and serious", "am_onyx", "am_fenrir", 0.40f, 0.93f, "documentary"),
        VoicePreset(8, "Calm Guide", "Relaxed, trustworthy male guide", "am_michael", "am_adam", 0.30f, 0.97f, "calm"),
        VoicePreset(9, "Friendly Guy", "Casual, friendly male voice", "am_puck", "am_liam", 0.30f, 1.02f, "conversational"),
        VoicePreset(10, "Documentary", "Classic British documentary narrator", "bm_george", "bm_fable", 0.35f, 0.96f, "documentary"),
        VoicePreset(11, "Dark Documentary", "Slow, serious British voice for mystery and suspense", "bm_george", "bm_lewis", 0.40f, 0.90f, "documentary")
    )

    fun friendlyVoiceLabel(voiceId: String): String {
        if (voiceId.startsWith("tf_") || voiceId.startsWith("tm_")) {
            val g = if (voiceId[1] == 'f') "female" else "male"
            val name = voiceId.substring(3).replace('_', ' ').replaceFirstChar { it.uppercase() }
            return "$name - Telugu $g"
        }
        val accent = when (voiceId.firstOrNull()) {
            'a' -> "American"
            'b' -> "British"
            'h' -> "Hindi"
            'e' -> "Spanish"
            'f' -> "French"
            'i' -> "Italian"
            'p' -> "Portuguese"
            else -> ""
        }
        val gender = if (voiceId.getOrNull(1) == 'f') "female" else "male"
        val cleanName = voiceId.drop(3).replace('_', ' ').replaceFirstChar { it.uppercase() }
        return "$cleanName - $accent $gender"
    }

    fun sampleTextForVoice(voiceId: String): String {
        if (voiceId.startsWith("tf_") || voiceId.startsWith("tm_")) {
            return SAMPLES["te"] ?: DEFAULT_SAMPLE_EN
        }
        val groupKey = when (voiceId.firstOrNull()) {
            'a' -> "en-us"
            'b' -> "en-gb"
            'h' -> "hi"
            'e' -> "es"
            'f' -> "fr"
            'i' -> "it"
            'p' -> "pt"
            't' -> "te"
            else -> "en-us"
        }
        return SAMPLES[groupKey] ?: DEFAULT_SAMPLE_EN
    }

    /**
     * Builds the complete 255-voice Kokoro combinatoric library + 3 Telugu voices (258 total).
     */
    fun buildFullVoiceLibrary(availableBaseVoices: List<String> = KOKORO_BASE_VOICES): Pair<List<VoiceLibraryEntry>, List<LanguageGroup>> {
        val groupSpecs = listOf(
            Triple('a', "en-us", "English - American"),
            Triple('b', "en-gb", "English - British"),
            Triple('t', "te", "Telugu - తెలుగు (India)"),
            Triple('h', "hi", "Hindi (India)"),
            Triple('e', "es", "Spanish"),
            Triple('f', "fr", "French"),
            Triple('i', "it", "Italian"),
            Triple('p', "pt", "Portuguese (Brazil)")
        )

        val usedNames = HashSet<String>()
        var femIdx = 0
        var malIdx = 0

        fun nextBlendName(genderCode: Char): String {
            val pool = if (genderCode == 'f') SHUFFLED_FEMALE_BLEND_NAMES else SHUFFLED_MALE_BLEND_NAMES
            while (if (genderCode == 'f') femIdx < pool.size else malIdx < pool.size) {
                val candidate = if (genderCode == 'f') pool[femIdx++] else pool[malIdx++]
                if (usedNames.add(candidate)) return candidate
            }
            val fallback = "Voice ${usedNames.size + 1}"
            usedNames.add(fallback)
            return fallback
        }

        val library = ArrayList<VoiceLibraryEntry>(260)
        val groups = ArrayList<LanguageGroup>(8)

        for ((prefix, gid, label) in groupSpecs) {
            if (gid == "te") {
                library.addAll(TELUGU_VOICES)
                groups.add(
                    LanguageGroup(
                        id = "te",
                        prefix = 't',
                        espeakLang = "te",
                        label = label,
                        count = TELUGU_VOICES.size,
                        isTeluguNative = true
                    )
                )
                continue
            }
            val espeakLang = when (prefix) {
                'a' -> "en-us"
                'b' -> "en-gb"
                'h' -> "hi"
                'e' -> "es"
                'f' -> "fr-fr"
                'i' -> "it"
                'p' -> "pt-br"
                else -> "en-us"
            }
            var groupCount = 0
            for ((gCode, gLabel) in listOf('f' to "Female", 'm' to "Male")) {
                val vs = availableBaseVoices.filter { it.length > 3 && it[0] == prefix && it[1] == gCode && it[2] == '_' }.sorted()
                // Single original voices
                for (v in vs) {
                    val cleanName = v.substring(3).replace('_', ' ').replaceFirstChar { it.uppercase() }
                    library.add(
                        VoiceLibraryEntry(
                            id = "$gid:$gCode:$v",
                            group = gid,
                            gender = gLabel,
                            name = cleanName,
                            voice = v,
                            blendVoice = null,
                            blend = 0.0f,
                            kind = "single"
                        )
                    )
                    groupCount++
                }
                // Ordered 2-voice permutations (60% primary, 40% secondary)
                for (i in vs.indices) {
                    for (j in vs.indices) {
                        if (i == j) continue
                        val a = vs[i]
                        val b = vs[j]
                        library.add(
                            VoiceLibraryEntry(
                                id = "$gid:$gCode:$a+$b",
                                group = gid,
                                gender = gLabel,
                                name = nextBlendName(gCode),
                                voice = a,
                                blendVoice = b,
                                blend = 0.40f,
                                kind = "blend"
                            )
                        )
                        groupCount++
                    }
                }
            }
            if (groupCount > 0) {
                groups.add(LanguageGroup(id = gid, prefix = prefix, espeakLang = espeakLang, label = label, count = groupCount))
            }
        }
        return library to groups
    }
}
