package com.voicestudio.android.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.voicestudio.android.MainActivity
import com.voicestudio.android.R
import com.voicestudio.android.VoiceStudioApplication

/**
 * Foreground Service keeping on-device ONNX inference alive when the user switches apps
 * or turns off the screen during a long voiceover script generation.
 */
class GenerationForegroundService : Service() {

    companion object {
        private const val NOTIFICATION_ID = 8765
        const val ACTION_START = "com.voicestudio.android.action.START_GEN"
        const val ACTION_UPDATE = "com.voicestudio.android.action.UPDATE_GEN"
        const val ACTION_STOP = "com.voicestudio.android.action.STOP_GEN"
        const val EXTRA_MESSAGE = "extra_message"
        const val EXTRA_PROGRESS = "extra_progress"

        fun startOrUpdate(context: Context, message: String, progressPct: Int) {
            try {
                val intent = Intent(context, GenerationForegroundService::class.java).apply {
                    action = ACTION_UPDATE
                    putExtra(EXTRA_MESSAGE, message)
                    putExtra(EXTRA_PROGRESS, progressPct)
                }
                context.startService(intent)
            } catch (_: Exception) {
            }
        }

        fun stop(context: Context) {
            try {
                val intent = Intent(context, GenerationForegroundService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
            } catch (_: Exception) {
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            else -> {
                val msg = intent?.getStringExtra(EXTRA_MESSAGE) ?: "Generating voiceover offline..."
                val pct = intent?.getIntExtra(EXTRA_PROGRESS, 0) ?: 0
                val notif = buildNotification(msg, pct)
                try {
                    startForeground(NOTIFICATION_ID, notif)
                } catch (_: Exception) {
                    val nm = getSystemService(NotificationManager::class.java)
                    nm?.notify(NOTIFICATION_ID, notif)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(message: String, pct: Int): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, VoiceStudioApplication.CHANNEL_ID_SYNTHESIS)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Voice Studio — Offline Engine")
            .setContentText(message)
            .setProgress(100, pct.coerceIn(0, 100), pct <= 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
