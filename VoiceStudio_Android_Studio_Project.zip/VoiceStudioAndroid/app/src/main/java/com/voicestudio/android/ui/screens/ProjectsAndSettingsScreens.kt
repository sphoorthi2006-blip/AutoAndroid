package com.voicestudio.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.voicestudio.android.data.model.ModelPackId
import com.voicestudio.android.data.model.SavedProjectItem
import com.voicestudio.android.ui.theme.StudioColors
import com.voicestudio.android.viewmodel.StudioUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Projects / History Screen:
 * - Lists all saved full voiceover generations stored locally on the device
 * - Supports Replay (`▶`), Load Script back into Studio, Rename, and Delete
 */
@Composable
fun ProjectsHistoryScreen(
    state: StudioUiState,
    onPlayProject: (SavedProjectItem) -> Unit,
    onLoadScriptIntoStudio: (String) -> Unit,
    onRenameProject: (String, String) -> Unit,
    onDeleteProject: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    var renameItem by remember { mutableStateOf<SavedProjectItem?>(null) }
    var renameTitle by remember { mutableStateOf("") }
    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy • HH:mm", Locale.US) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Text(
                text = "SAVED PROJECTS & GENERATION HISTORY (${state.savedProjects.size})",
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "All generated voiceovers are saved privately in local device storage and work 100% offline.",
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (state.savedProjects.isEmpty()) {
                Text(
                    text = "No saved voiceover projects yet. Generate a full voiceover in the Studio tab to save it here automatically.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudioColors.TextMuted
                )
            } else {
                state.savedProjects.forEach { proj ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(StudioColors.PanelElevated)
                            .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = proj.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${proj.voiceLabel} • ${String.format("%.1fs", proj.durationSec)} • ${dateFormat.format(Date(proj.createdAtEpochMs))}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Row {
                                IconButton(onClick = { onPlayProject(proj) }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Replay", tint = StudioColors.AccentTeal)
                                }
                                IconButton(onClick = {
                                    renameItem = proj
                                    renameTitle = proj.title
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Rename", tint = StudioColors.TextMuted)
                                }
                                IconButton(onClick = { onDeleteProject(proj.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StudioColors.DangerRed)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = proj.scriptSnippet,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = { onLoadScriptIntoStudio(proj.fullScript) },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Open Script in Studio", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    if (renameItem != null) {
        AlertDialog(
            onDismissRequest = { renameItem = null },
            title = { Text("Rename Saved Voiceover") },
            text = {
                OutlinedTextField(
                    value = renameTitle,
                    onValueChange = { renameTitle = it },
                    singleLine = true,
                    label = { Text("Title") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    renameItem?.let { onRenameProject(it.id, renameTitle) }
                    renameItem = null
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameItem = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

/**
 * Settings & Offline Model Management Screen:
 * - Displays installation & SHA-256 verification status for:
 *   1. `Kokoro-82M v1.0` (`kokoro-v1.0.onnx` + `voices-v1.0.bin`, Apache-2.0)
 *   2. `OpenVoice V2` (`tone_extract.onnx` + `tone_color.onnx`, MIT)
 *   3. `Meta MMS-TTS Telugu VITS` (`mms-tts-tel.onnx`, CC-BY-NC 4.0)
 * - Supports 1-tap official download with progress bar OR 100% offline manual file/ZIP import via SAF
 * - Displays device storage, privacy policy (100% local, zero telemetry), and OSS attributions
 */
@Composable
fun ModelManagementAndSettingsScreen(
    state: StudioUiState,
    onDownloadPack: (ModelPackId) -> Unit,
    onDeletePack: (ModelPackId) -> Unit,
    onManualImportFileClick: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Offline Model Import & Storage Banner
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("OFFLINE AI MODEL MANAGEMENT", style = MaterialTheme.typography.labelSmall)
                Text("Free space: ${state.availableStorageMb}", style = MaterialTheme.typography.bodySmall, color = StudioColors.AccentTeal)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Already have kokoro-v1.0.onnx, voices-v1.0.bin, or VoiceStudio-Models.zip on your phone? Import them directly offline without downloading.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onManualImportFileClick,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentViolet)
            ) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Import Model File (.onnx / .bin / .zip) From Device", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        // Individual Model Pack Cards
        state.modelPacks.forEach { packStatus ->
            val pack = packStatus.pack
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(StudioColors.Panel)
                    .border(
                        width = 1.dp,
                        color = if (packStatus.isInstalled) StudioColors.AccentTeal else StudioColors.BorderLine,
                        shape = RoundedCornerShape(14.dp)
                    )
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(pack.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(pack.subtitle, style = MaterialTheme.typography.bodySmall)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("License: ${pack.licenseName}", style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
                    }
                    if (packStatus.isInstalled) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Installed",
                            tint = StudioColors.StatusReadyGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = packStatus.statusMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (packStatus.isInstalled) StudioColors.AccentTeal else StudioColors.TextMuted
                )

                if (packStatus.isDownloading) {
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { (packStatus.progressPct / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = StudioColors.AccentTeal,
                        trackColor = StudioColors.PanelElevated
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!packStatus.isInstalled) {
                        Button(
                            onClick = { onDownloadPack(pack) },
                            enabled = !packStatus.isDownloading,
                            shape = RoundedCornerShape(9.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentViolet)
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (packStatus.isDownloading) "Downloading (${packStatus.progressPct}%)" else "Download Official Pack", color = Color.White)
                        }
                    } else {
                        OutlinedButton(
                            onClick = { onDeletePack(pack) },
                            shape = RoundedCornerShape(9.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = StudioColors.DangerRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Remove Pack", color = StudioColors.DangerRed)
                        }
                    }
                }
            }
        }

        // Privacy, Offline Architecture & Licenses Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Text("PRIVACY, OFFLINE OPERATION & OPEN-SOURCE NOTICES", style = MaterialTheme.typography.labelSmall)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "• 100% On-Device Inference: All text-to-speech synthesis, voice blending, reference voice cloning, and Telugu VITS generation run locally on your phone via ONNX Runtime Mobile.\n" +
                        "• Zero Cloud / Zero Telemetry: Your scripts, voice recordings, and generated audio never leave your device.\n" +
                        "• Airplane Mode Ready: Once model files are imported or downloaded, the app operates completely offline in Airplane Mode.\n" +
                        "• Licenses: Kokoro-82M weights (Apache-2.0, hexgrad), kokoro-onnx (MIT, thewh1teagle), OpenVoice V2 (MIT, MyShell), MMS-TTS Telugu VITS (CC-BY-NC 4.0, Meta AI), ONNX Runtime Android (MIT, Microsoft).",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
