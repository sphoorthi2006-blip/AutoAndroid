package com.voicestudio.android.domain

import com.voicestudio.android.data.model.ConversationStyle
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Exact port of tts_core.py + studio.js script processing:
 * - [pause] and [pause N.N] tag parsing
 * - Paragraph, sentence (ASCII + ellipsis + Devanagari/Telugu danda), clause, and word-boundary chunking
 * - Deterministic pacing schedule (seed = 7) computing per-chunk speed jitter and inter-chunk gaps
 * - Zero-allocation word counter and duration estimator
 * - Smart preview text extraction
 */
object ScriptPlanner {

    private val PAUSE_REGEX = Regex("\\[pause(?:\\s+([0-9]*\\.?[0-9]+))?\\]", RegexOption.IGNORE_CASE)
    private val PARAGRAPH_SPLIT_REGEX = Regex("\\n+")
    private val WHITESPACE_COLLAPSE_REGEX = Regex("\\s+")
    // Supports ASCII .!?, ellipsis \u2026, Devanagari danda \u0964, double danda \u0965
    private val SENTENCE_SPLIT_REGEX = Regex("(?<=[.!?\\u2026\\u0964\\u0965])\\s+")
    private val CLAUSE_SPLIT_REGEX = Regex("(?<=[,;:])\\s+")

    sealed class ScriptSegment {
        data class TextSegment(val text: String) : ScriptSegment()
        data class PauseSegment(val seconds: Float) : ScriptSegment()
    }

    sealed class SynthesisStep {
        data class SpeakStep(
            val index: Int,
            val text: String,
            val endsParagraph: Boolean,
            val effectiveSpeed: Float,
            val postGapSeconds: Float
        ) : SynthesisStep()

        data class SilenceStep(
            val index: Int,
            val seconds: Float
        ) : SynthesisStep()
    }

    /**
     * Split script on [pause] or [pause 1.5] tags, matching parse_script(text) in tts_core.py.
     */
    fun parseScript(text: String): List<ScriptSegment> {
        val segments = ArrayList<ScriptSegment>()
        var pos = 0
        for (match in PAUSE_REGEX.findAll(text)) {
            if (match.range.first > pos) {
                segments.add(ScriptSegment.TextSegment(text.substring(pos, match.range.first)))
            }
            val secStr = match.groupValues.getOrNull(1)
            val secs = secStr?.toFloatOrNull()?.coerceIn(0.05f, 30.0f) ?: 1.0f
            segments.add(ScriptSegment.PauseSegment(secs))
            pos = match.range.last + 1
        }
        if (pos < text.length) {
            segments.add(ScriptSegment.TextSegment(text.substring(pos)))
        }
        return segments
    }

    /**
     * Split a block of text into chunks <= maxChars, returning pairs of (chunkText, endsParagraph).
     * Matches split_text(text, max_chars) in tts_core.py.
     */
    fun splitText(text: String, maxChars: Int = 350): List<Pair<String, Boolean>> {
        val result = ArrayList<Pair<String, Boolean>>()
        val paragraphs = PARAGRAPH_SPLIT_REGEX.split(text).map { it.trim() }.filter { it.isNotEmpty() }
        for (rawPara in paragraphs) {
            val para = WHITESPACE_COLLAPSE_REGEX.replace(rawPara, " ")
            val units = ArrayList<String>()
            for (sent in SENTENCE_SPLIT_REGEX.split(para)) {
                if (sent.length <= maxChars) {
                    if (sent.isNotEmpty()) units.add(sent)
                    continue
                }
                for (clause in CLAUSE_SPLIT_REGEX.split(sent)) {
                    var part = clause
                    while (part.length > maxChars) {
                        var cut = part.lastIndexOf(' ', maxChars)
                        if (cut <= 0) cut = maxChars
                        units.add(part.substring(0, cut))
                        part = part.substring(cut).trimStart()
                    }
                    if (part.isNotEmpty()) units.add(part)
                }
            }
            val chunks = ArrayList<String>()
            var cur = ""
            for (u in units) {
                if (cur.isNotEmpty() && cur.length + 1 + u.length > maxChars) {
                    chunks.add(cur)
                    cur = u
                } else {
                    cur = if (cur.isEmpty()) u else "$cur $u"
                }
            }
            if (cur.isNotEmpty()) chunks.add(cur)
            for (i in chunks.indices) {
                result.add(chunks[i] to (i == chunks.lastIndex))
            }
        }
        return result
    }

    /**
     * Build a complete deterministic synthesis plan for a script, base speed, and conversation style.
     */
    fun buildSynthesisPlan(
        script: String,
        baseSpeed: Float,
        style: ConversationStyle
    ): List<SynthesisStep> {
        val rng = Random(7) // Fixed seed so identical scripts always get identical pacing
        val rawPlan = ArrayList<Pair<String, Any>>()
        for (seg in parseScript(script)) {
            when (seg) {
                is ScriptSegment.PauseSegment -> rawPlan.add("pause" to seg.seconds)
                is ScriptSegment.TextSegment -> {
                    for ((chunk, endsPara) in splitText(seg.text, style.maxChars)) {
                        rawPlan.add("speak" to (chunk to endsPara))
                    }
                }
            }
        }

        val steps = ArrayList<SynthesisStep>(rawPlan.size)
        for ((idx, item) in rawPlan.withIndex()) {
            if (item.first == "pause") {
                steps.add(SynthesisStep.SilenceStep(idx, item.second as Float))
            } else {
                @Suppress("UNCHECKED_CAST")
                val chunkPair = item.second as Pair<String, Boolean>
                val (chunk, endsPara) = chunkPair
                val jitterFactor = if (style.jitter > 0f) {
                    1.0f - style.jitter + rng.nextFloat() * (2.0f * style.jitter)
                } else {
                    1.0f
                }
                val sp = (baseSpeed * style.speedMultiplier * jitterFactor).coerceIn(0.5f, 2.0f)
                var gap = if (endsPara) {
                    style.paraPauseSec
                } else {
                    style.shortPauseMinSec + rng.nextFloat() * (style.shortPauseMaxSec - style.shortPauseMinSec)
                }
                val trimmed = chunk.trimEnd()
                if (trimmed.endsWith("?") || trimmed.endsWith("!")) {
                    gap += style.questionBonusSec
                }
                steps.add(SynthesisStep.SpeakStep(idx, chunk, endsPara, sp, gap))
            }
        }
        return steps
    }

    /**
     * Fast word count ignoring [pause] tags, matching countWordsFast(raw) in studio.js.
     */
    fun countWordsFast(raw: String): Int {
        if (raw.isEmpty()) return 0
        val cleaned = if (raw.contains('[')) PAUSE_REGEX.replace(raw, " ") else raw
        var count = 0
        var inWord = false
        for (i in cleaned.indices) {
            val c = cleaned[i]
            val isSpace = c.code <= 32 || (c.code in 0x2000..0x200A) || c.code == 0x00A0 || c.code == 0x3000
            if (!isSpace) {
                if (!inWord) {
                    count++
                    inWord = true
                }
            } else {
                inWord = false
            }
        }
        return count
    }

    /**
     * Estimate audio duration in seconds from word count and speed multiplier (150 wpm @ 1.0x).
     */
    fun estimateDurationSeconds(wordCount: Int, speedMultiplier: Float): Int {
        if (wordCount <= 0) return 0
        val secs = (wordCount / (150f * speedMultiplier.coerceAtLeast(0.5f))) * 60f
        return secs.roundToInt().coerceAtLeast(1)
    }

    /**
     * Extract preview snippet from selected text or opening of script, matching previewText() in studio.js.
     */
    fun extractPreviewText(
        fullScript: String,
        selectionStart: Int = 0,
        selectionEnd: Int = 0,
        defaultSample: String = VoiceStudioCatalog.DEFAULT_SAMPLE_EN
    ): String {
        if (selectionEnd > selectionStart && selectionStart >= 0 && selectionEnd <= fullScript.length) {
            val sel = PAUSE_REGEX.replace(fullScript.substring(selectionStart, selectionEnd), " ")
                .replace(WHITESPACE_COLLAPSE_REGEX, " ")
                .trim()
            if (sel.isNotEmpty()) return sel.take(900)
        }
        val rawSlice = PAUSE_REGEX.replace(fullScript.take(1200), " ")
            .replace(WHITESPACE_COLLAPSE_REGEX, " ")
            .trim()
        if (rawSlice.isEmpty()) return defaultSample
        if (rawSlice.length <= 320) return rawSlice
        val cut = rawSlice.substring(0, 320)
        val lastPeriod = maxOf(
            cut.lastIndexOf(". "),
            cut.lastIndexOf("? "),
            cut.lastIndexOf("! "),
            cut.lastIndexOf("। ")
        )
        return if (lastPeriod > 80) cut.substring(0, lastPeriod + 1) else cut
    }
}
