package com.voicestudio.android

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class VoiceStudioUiSmokeTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun testBottomNavigationAndStudioTabsRender() {
        composeTestRule.onNodeWithText("Voice Studio").assertExists()
        composeTestRule.onNodeWithText("Voices & Mix").performClick()
        composeTestRule.onNodeWithText("VOICE LIBRARY").assertExists()
        composeTestRule.onNodeWithText("My Voice").performClick()
        composeTestRule.onNodeWithText("MY VOICE — ZERO-SHOT REFERENCE VOICE CLONING").assertExists()
        composeTestRule.onNodeWithText("Projects").performClick()
        composeTestRule.onNodeWithText("Models").performClick()
        composeTestRule.onNodeWithText("OFFLINE AI MODEL MANAGEMENT").assertExists()
    }
}
