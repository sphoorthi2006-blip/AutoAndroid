package com.voicestudio.android.engine

import java.util.Locale

/**
 * Offline Grapheme-to-Phoneme (G2P) & Accent Adaptation Phonemizer for Kokoro-82M.
 *
 * Supports:
 * - American English ("en-us")
 * - British English ("en-gb")
 * - Australian English ("en-au") — vowel shifts (FACE /æɪ/, PRICE /ɑe/, GOAT /ɐʉ/, non-rhotic)
 * - Indian English ("en-in") — syllable-timed vowels, retroflex coronal stops (/ʈ/, /ɖ/), rhotic /r/
 * - Hindi ("hi" — Devanagari to IPA)
 * - Spanish ("es")
 * - French ("fr-fr")
 * - Italian ("it")
 * - Brazilian Portuguese ("pt-br")
 *
 * Also exposes a JNI bridge hook (`NativeEspeakBridge`) if `libespeak-ng.so` is bundled in `jniLibs`.
 */
interface OfflinePhonemizer {
    fun phonemize(text: String, langCode: String): String
}

class MultilingualG2pPhonemizer : OfflinePhonemizer {

    companion object {
        // Core high-frequency English IPA lexicon (American English base; adapted dynamically for UK/AU/IN)
        private val EN_LEXICON: Map<String, String> = mapOf(
            "welcome" to "wˈɛlkəm",
            "back" to "bˈæk",
            "today" to "tədˈeɪ",
            "we're" to "wˈɪɹ",
            "we" to "wˈiː",
            "are" to "ˈɑːɹ",
            "going" to "ɡˈoʊɪŋ",
            "to" to "tə",
            "talk" to "tˈɔːk",
            "about" to "əbˈaʊt",
            "something" to "sˈʌmθɪŋ",
            "most" to "mˈoʊst",
            "people" to "pˈiːpəl",
            "never" to "nˈɛvɚ",
            "stop" to "stˈɑːp",
            "think" to "θˈɪŋk",
            "and" to "ænd",
            "honestly" to "ˈɑːnɪstli",
            "once" to "wˈʌns",
            "you" to "jˈuː",
            "see" to "sˈiː",
            "it" to "ˈɪt",
            "changes" to "ʧˈeɪnʤɪz",
            "everything" to "ˈɛvɹiθˌɪŋ",
            "hello" to "həlˈoʊ",
            "there" to "ðˈɛɹ",
            "voice" to "vˈɔɪs",
            "studio" to "stˈuːdiˌoʊ",
            "offline" to "ˈɔːflˌaɪn",
            "natural" to "nˈæʧəɹəl",
            "speech" to "spˈiːʧ",
            "generation" to "ʤˌɛnəɹˈeɪʃən",
            "android" to "ˈændɹɔɪd",
            "phone" to "fˈoʊn",
            "without" to "wɪðˈaʊt",
            "internet" to "ˈɪntɚnˌɛt",
            "world" to "wˈɜːld",
            "story" to "stˈɔːɹi",
            "time" to "tˈaɪm",
            "life" to "lˈaɪf",
            "is" to "ˈɪz",
            "like" to "lˈaɪk",
            "a" to "ə",
            "the" to "ðə",
            "of" to "ʌv",
            "in" to "ɪn",
            "for" to "fɔːɹ",
            "on" to "ɑːn",
            "with" to "wɪð",
            "this" to "ðˈɪs",
            "that" to "ðˈæt",
            "from" to "fɹˈʌm",
            "your" to "jˈɔːɹ",
            "my" to "mˈaɪ",
            "can" to "kˈæn",
            "will" to "wˈɪl",
            "have" to "hˈæv",
            "has" to "hˈæz",
            "not" to "nˈɑːt",
            "but" to "bˈʌt",
            "what" to "wˈʌt",
            "when" to "wˈɛn",
            "where" to "wˈɛɹ",
            "who" to "hˈuː",
            "how" to "hˈaʊ",
            "why" to "wˈaɪ",
            "all" to "ˈɔːl",
            "one" to "wˈʌn",
            "two" to "tˈuː",
            "three" to "θɹˈiː",
            "four" to "fˈɔːɹ",
            "five" to "fˈaɪv"
        )

        // Devanagari (Hindi) consonant base mappings to Kokoro IPA
        private val DEVANAGARI_CONSONANTS: Map<Char, String> = mapOf(
            'क' to "k", 'ख' to "kʰ", 'ग' to "ɡ", 'घ' to "ɡʱ", 'ङ' to "ŋ",
            'च' to "ʧ", 'छ' to "ʧʰ", 'ज' to "ʤ", 'झ' to "ʤʱ", 'ञ' to "ɲ",
            'ट' to "ʈ", 'ठ' to "ʈʰ", 'ड' to "ɖ", 'ढ' to "ɖʱ", 'ण' to "ɳ",
            'त' to "t", 'थ' to "tʰ", 'द' to "d", 'ध' to "dʱ", 'न' to "n",
            'प' to "p", 'फ' to "pʰ", 'ब' to "b", 'भ' to "bʱ", 'म' to "m",
            'य' to "j", 'र' to "ɾ", 'ल' to "l", 'व' to "ʋ",
            'श' to "ʃ", 'ष' to "ʂ", 'स' to "s", 'ह' to "h",
            '\u095C' to "ɽ", '\u095D' to "ɽʱ", '\u095B' to "z", '\u095E' to "f"
        )

        private val DEVANAGARI_MATRAS: Map<Char, String> = mapOf(
            'ा' to "ɑː", 'ि' to "ɪ", 'ी' to "iː", 'ु' to "ʊ", 'ू' to "uː",
            'े' to "eː", 'ै' to "ɛː", 'ो' to "oː", 'ौ' to "ɔː", 'ृ' to "ɾɪ",
            'ं' to "n", 'ँ' to "\u0303", 'ः' to "h"
        )

        private val DEVANAGARI_VOWELS: Map<Char, String> = mapOf(
            'अ' to "ə", 'आ' to "ɑː", 'इ' to "ɪ", 'ई' to "iː",
            'उ' to "ʊ", 'ऊ' to "uː", 'ऋ' to "ɾɪ", 'ए' to "eː",
            'ऐ' to "ɛː", 'ओ' to "oː", 'औ' to "ɔː"
        )
    }

    override fun phonemize(text: String, langCode: String): String {
        val normalized = normalizeNumbersAndSymbols(text.trim(), langCode)
        return when (langCode.lowercase(Locale.ROOT)) {
            "hi" -> phonemizeHindi(normalized)
            "es" -> phonemizeSpanish(normalized)
            "fr", "fr-fr" -> phonemizeFrench(normalized)
            "it" -> phonemizeItalian(normalized)
            "pt", "pt-br" -> phonemizePortuguese(normalized)
            "en-gb" -> adaptEnglishAccent(phonemizeEnglishBase(normalized), "en-gb")
            "en-au" -> adaptEnglishAccent(phonemizeEnglishBase(normalized), "en-au")
            "en-in" -> adaptEnglishAccent(phonemizeEnglishBase(normalized), "en-in")
            else -> phonemizeEnglishBase(normalized)
        }
    }

    private fun normalizeNumbersAndSymbols(text: String, lang: String): String {
        return text
            .replace("%", " percent ")
            .replace("&", " and ")
            .replace("—", ", ")
            .replace("–", ", ")
    }

    private fun phonemizeEnglishBase(text: String): String {
        val sb = StringBuilder(text.length * 2)
        val tokenRegex = Regex("""([A-Za-z']+)|([^A-Za-z']+)""")
        for (m in tokenRegex.findAll(text)) {
            val word = m.groups[1]?.value
            if (word != null) {
                val lower = word.lowercase(Locale.ROOT)
                val lex = EN_LEXICON[lower]
                if (lex != null) {
                    sb.append(lex)
                } else {
                    sb.append(englishRuleG2p(lower))
                }
            } else {
                val punct = m.groups[2]?.value ?: ""
                for (ch in punct) {
                    if (ch in ";:,.!?—…\"()“” ") sb.append(ch)
                }
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Rule-based English G2P for out-of-vocabulary words producing valid Kokoro IPA tokens.
     */
    private fun englishRuleG2p(word: String): String {
        var s = word
        s = s.replace("tion", "ʃən")
            .replace("sion", "ʒən")
            .replace("ough", "oʊ")
            .replace("igh", "aɪ")
            .replace("tch", "ʧ")
            .replace("dge", "ʤ")
            .replace("ch", "ʧ")
            .replace("sh", "ʃ")
            .replace("th", "θ")
            .replace("ph", "f")
            .replace("wh", "w")
            .replace("kn", "n")
            .replace("wr", "ɹ")
            .replace("ng", "ŋ")
            .replace("qu", "kw")
            .replace("ee", "iː")
            .replace("ea", "iː")
            .replace("oo", "uː")
            .replace("ou", "aʊ")
            .replace("ow", "aʊ")
            .replace("oi", "ɔɪ")
            .replace("oy", "ɔɪ")
            .replace("ai", "eɪ")
            .replace("ay", "eɪ")
            .replace("au", "ɔː")
            .replace("aw", "ɔː")
            .replace("ar", "ɑːɹ")
            .replace("er", "ɚ")
            .replace("ir", "ɜːɹ")
            .replace("ur", "ɜːɹ")
            .replace("or", "ɔːɹ")

        val out = StringBuilder("ˈ")
        for (i in s.indices) {
            val c = s[i]
            when (c) {
                'a' -> out.append('æ')
                'e' -> if (i != s.lastIndex || s.length <= 3) out.append('ɛ')
                'i' -> out.append('ɪ')
                'o' -> out.append('ɑ')
                'u' -> out.append('ʌ')
                'y' -> out.append(if (i == 0) 'j' else 'i')
                'c' -> out.append(if (i + 1 < s.length && s[i + 1] in "eiy") 's' else 'k')
                'g' -> out.append('ɡ')
                'r' -> out.append('ɹ')
                'j' -> out.append('ʤ')
                else -> out.append(c)
            }
        }
        return out.toString()
    }

    /**
     * Applies regional phonological rules to transform General American IPA into:
     * - British English ("en-gb"): non-rhotic coda /ɹ/ deletion, LOT /ɒ/, BATH /ɑː/, GOAT /əʊ/
     * - Australian English ("en-au"): non-rhotic, FACE /æɪ/, PRICE /ɑe/, GOAT /ɐʉ/, nurse /ɜː/
     * - Indian English ("en-in"): retroflex stops /ʈ/ & /ɖ/, dental stops for /θ/ & /ð/, clear syllable-timed vowels (/eː/, /oː/)
     */
    private fun adaptEnglishAccent(usIpa: String, accentCode: String): String {
        return when (accentCode) {
            "en-gb" -> usIpa
                .replace("oʊ", "əʊ")
                .replace("ɚ", "ə")
                .replace("ɑːɹ", "ɑː")
                .replace("ɔːɹ", "ɔː")
                .replace("ɜːɹ", "ɜː")
                .replace(Regex("ɹ(?=[\\s.,!?;:]|$)"), "")
            "en-au" -> usIpa
                .replace("eɪ", "æɪ")
                .replace("aɪ", "ɑe")
                .replace("oʊ", "ɐʉ")
                .replace("ɚ", "ə")
                .replace("ɑːɹ", "ɑː")
                .replace("ɔːɹ", "oː")
                .replace(Regex("ɹ(?=[\\s.,!?;:]|$)"), "")
            "en-in" -> usIpa
                .replace("eɪ", "eː")
                .replace("oʊ", "oː")
                .replace("θ", "tʰ")
                .replace("ð", "d")
                .replace("t", "ʈ")
                .replace("d", "ɖ")
                .replace("ɚ", "ər")
                .replace("ɹ", "ɾ")
            else -> usIpa
        }
    }

    private fun phonemizeHindi(text: String): String {
        val sb = StringBuilder(text.length * 2)
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                ch == '।' || ch == '॥' -> sb.append('.')
                DEVANAGARI_VOWELS.containsKey(ch) -> sb.append(DEVANAGARI_VOWELS[ch])
                DEVANAGARI_CONSONANTS.containsKey(ch) -> {
                    sb.append(DEVANAGARI_CONSONANTS[ch])
                    val next = text.getOrNull(i + 1)
                    when {
                        next == '्' -> i++ // Virama suppresses inherent schwa
                        next != null && DEVANAGARI_MATRAS.containsKey(next) -> {
                            sb.append(DEVANAGARI_MATRAS[next])
                            i++
                        }
                        next == null || next.isWhitespace() || next in ".,!?;:।॥" -> {
                            // Word-final schwa deletion in modern spoken Hindi
                        }
                        else -> sb.append('ə')
                    }
                }
                DEVANAGARI_MATRAS.containsKey(ch) -> sb.append(DEVANAGARI_MATRAS[ch])
                ch in ";:,.!?—…\"()“” " -> sb.append(ch)
                ch.isLetterOrDigit() -> sb.append(ch.lowercaseChar())
            }
            i++
        }
        return sb.toString()
    }

    private fun phonemizeSpanish(text: String): String {
        var s = text.lowercase(Locale.ROOT)
            .replace("ll", "ʝ")
            .replace("ñ", "ɲ")
            .replace("ch", "ʧ")
            .replace("rr", "r")
            .replace("qu", "k")
            .replace("gue", "ɡe")
            .replace("gui", "ɡi")
            .replace("ce", "se")
            .replace("ci", "si")
            .replace("ge", "xe")
            .replace("gi", "xi")
            .replace("j", "x")
            .replace("h", "")
            .replace("v", "b")
            .replace("z", "s")
            .replace("á", "ˈa")
            .replace("é", "ˈe")
            .replace("í", "ˈi")
            .replace("ó", "ˈo")
            .replace("ú", "ˈu")
        return s
    }

    private fun phonemizeFrench(text: String): String {
        return text.lowercase(Locale.ROOT)
            .replace("eau", "o")
            .replace("au", "o")
            .replace("ou", "u")
            .replace("oi", "wa")
            .replace("ch", "ʃ")
            .replace("gn", "ɲ")
            .replace("ph", "f")
            .replace("qu", "k")
            .replace("th", "t")
            .replace("é", "e")
            .replace("è", "ɛ")
            .replace("ê", "ɛ")
            .replace("à", "a")
            .replace("ç", "s")
            .replace("r", "ʁ")
    }

    private fun phonemizeItalian(text: String): String {
        return text.lowercase(Locale.ROOT)
            .replace("gli", "ʎi")
            .replace("gn", "ɲ")
            .replace("sci", "ʃi")
            .replace("sce", "ʃe")
            .replace("ch", "k")
            .replace("gh", "ɡ")
            .replace("ci", "ʧi")
            .replace("ce", "ʧe")
            .replace("gi", "ʤi")
            .replace("ge", "ʤe")
            .replace("à", "ˈa")
            .replace("è", "ˈɛ")
            .replace("é", "ˈe")
            .replace("ì", "ˈi")
            .replace("ò", "ˈɔ")
            .replace("ó", "ˈo")
            .replace("ù", "ˈu")
    }

    private fun phonemizePortuguese(text: String): String {
        return text.lowercase(Locale.ROOT)
            .replace("nh", "ɲ")
            .replace("lh", "ʎ")
            .replace("ch", "ʃ")
            .replace("rr", "ʁ")
            .replace("qu", "k")
            .replace("ç", "s")
            .replace("ã", "ɐ\u0303")
            .replace("õ", "o\u0303")
            .replace("á", "ˈa")
            .replace("é", "ˈɛ")
            .replace("ê", "ˈe")
            .replace("í", "ˈi")
            .replace("ó", "ˈɔ")
            .replace("ô", "ˈo")
            .replace("ú", "ˈu")
    }
}
