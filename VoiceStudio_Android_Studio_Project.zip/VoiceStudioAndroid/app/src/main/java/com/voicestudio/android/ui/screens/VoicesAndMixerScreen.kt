package com.voicestudio.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.voicestudio.android.domain.VoiceStudioCatalog
import com.voicestudio.android.ui.theme.StudioColors
import com.voicestudio.android.viewmodel.StudioUiState

/**
 * Voices, Presets & Custom Mixer Screen (`extension/studio.html` aside panel):
 * - Language / Accent filter (`★ Favorites` + 8 groups: American, British, Telugu తెలుగు, Hindi, Spanish, French, Italian, Portuguese)
 * - Gender filter (`All`, `Female`, `Male`)
 * - 258-Voice Library with `◀` / `▶` step-and-audition, `▶ Hear voice`, `☆ Favorite`, and `Shuffle`
 * - Custom Mix (Advanced) section with `Main voice` (`▶`), `Blend with` (`▶`), and `0%–100%` blend slider
 */
@Composable
fun VoicesAndMixerScreen(
    state: StudioUiState,
    onSelectGroup: (String) -> Unit,
    onSelectGender: (String) -> Unit,
    onSelectLibraryVoice: (String, Boolean) -> Unit,
    onStepVoice: (Int) -> Unit,
    onHearCurrentVoice: () -> Unit,
    onToggleFavorite: () -> Unit,
    onShuffleVoice: () -> Unit,
    onCustomMainVoiceChange: (String) -> Unit,
    onCustomBlendVoiceChange: (String) -> Unit,
    onCustomBlendPctChange: (Int) -> Unit,
    onAuditionSingleBaseVoice: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    var groupMenuOpen by remember { mutableStateOf(false) }
    var mainVoiceMenuOpen by remember { mutableStateOf(false) }
    var blendVoiceMenuOpen by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Voice Library Filter Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("VOICE LIBRARY", style = MaterialTheme.typography.labelSmall)
                Text("${state.filteredLibrary.size} voices", style = MaterialTheme.typography.bodySmall)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Language / Accent Dropdown
            Text("Language / accent", style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(4.dp))
            Box(modifier = Modifier.fillMaxWidth()) {
                val curGroupLabel = if (state.selectedGroupId == "fav") {
                    "★ Favorites (${state.favorites.size})"
                } else {
                    val g = state.groups.firstOrNull { it.id == state.selectedGroupId }
                    if (g != null) "${g.label} (${g.count})" else state.selectedGroupId
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(9.dp))
                        .background(StudioColors.PanelElevated)
                        .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(9.dp))
                        .clickable { groupMenuOpen = true }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(curGroupLabel, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Text("▼", color = StudioColors.TextMuted)
                }

                DropdownMenu(
                    expanded = groupMenuOpen,
                    onDismissRequest = { groupMenuOpen = false },
                    modifier = Modifier.background(StudioColors.PanelElevated)
                ) {
                    DropdownMenuItem(
                        text = { Text("★ Favorites (${state.favorites.size})", color = StudioColors.StatusWorkAmber, fontWeight = FontWeight.Bold) },
                        onClick = {
                            onSelectGroup("fav")
                            groupMenuOpen = false
                        }
                    )
                    state.groups.forEach { grp ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "${grp.label} (${grp.count})",
                                    color = if (grp.isTeluguNative) StudioColors.AccentTeal else StudioColors.TextPrimary
                                )
                            },
                            onClick = {
                                onSelectGroup(grp.id)
                                groupMenuOpen = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Gender Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("all" to "All Genders", "Female" to "Female", "Male" to "Male").forEach { (id, label) ->
                    FilterChip(
                        selected = state.selectedGender == id,
                        onClick = { onSelectGender(id) },
                        label = { Text(label, fontSize = 12.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StudioColors.PresetActiveSurface,
                            selectedLabelColor = StudioColors.AccentTeal
                        )
                    )
                }
            }

            if (state.libraryNote.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(state.libraryNote, style = MaterialTheme.typography.bodySmall, color = StudioColors.AccentTeal)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Step Controls & Audition / Favorite / Shuffle Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onStepVoice(-1) },
                    enabled = !state.isBusyGenerating && state.filteredLibrary.isNotEmpty(),
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Previous voice")
                }

                val selectedItem = state.filteredLibrary.firstOrNull { it.id == state.selectedLibraryId }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(StudioColors.PanelElevated)
                        .border(1.dp, StudioColors.AccentViolet, RoundedCornerShape(9.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = selectedItem?.name ?: "No voice in filter",
                        style = MaterialTheme.typography.titleMedium,
                        color = StudioColors.TextPrimary
                    )
                    Text(
                        text = when (selectedItem?.kind) {
                            "single" -> "Original single voice (${selectedItem.gender})"
                            "telugu_vits" -> "Native Telugu VITS voice (${selectedItem.gender})"
                            "blend" -> "60/40 Studio Blend (${selectedItem.gender})"
                            else -> ""
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp
                    )
                }

                OutlinedButton(
                    onClick = { onStepVoice(1) },
                    enabled = !state.isBusyGenerating && state.filteredLibrary.isNotEmpty(),
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Next voice")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val isFav = state.selectedLibraryId in state.favorites
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onHearCurrentVoice,
                    enabled = !state.isBusyGenerating && state.filteredLibrary.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(9.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentViolet)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Hear voice", fontSize = 13.sp, color = Color.White)
                }

                OutlinedButton(
                    onClick = onToggleFavorite,
                    enabled = state.selectedLibraryId.isNotEmpty(),
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Icon(
                        imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = null,
                        tint = if (isFav) StudioColors.StatusWorkAmber else StudioColors.TextPrimary,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isFav) "Favorited" else "Favorite",
                        color = if (isFav) StudioColors.StatusWorkAmber else StudioColors.TextPrimary,
                        fontSize = 13.sp
                    )
                }

                OutlinedButton(
                    onClick = onShuffleVoice,
                    enabled = !state.isBusyGenerating && state.filteredLibrary.isNotEmpty(),
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Shuffle", fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Scrollable Voice List within the Selected Language/Gender Group
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 160.dp, max = 260.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(StudioColors.PanelElevated)
                    .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(10.dp))
            ) {
                items(state.filteredLibrary, key = { it.id }) { item ->
                    val isSelected = item.id == state.selectedLibraryId
                    val itemFav = item.id in state.favorites
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isSelected) StudioColors.PresetActiveSurface else Color.Transparent)
                            .clickable { onSelectLibraryVoice(item.id, true) }
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.name + if (item.kind == "single") " (original)" else "",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) StudioColors.AccentTeal else StudioColors.TextPrimary
                            )
                            val recipe = if (item.blendVoice != null) {
                                "60% ${VoiceStudioCatalog.friendlyVoiceLabel(item.voice)} + 40% ${VoiceStudioCatalog.friendlyVoiceLabel(item.blendVoice)}"
                            } else {
                                VoiceStudioCatalog.friendlyVoiceLabel(item.voice)
                            }
                            Text(recipe, style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
                        }
                        if (itemFav) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Favorite",
                                tint = StudioColors.StatusWorkAmber,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Custom Mix (Advanced) Card — 1:1 with `<details class="adv"><summary>Custom mix (advanced)</summary>`
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioColors.Panel)
                .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Text("CUSTOM MIX (ADVANCED TWO-VOICE BLENDER)", style = MaterialTheme.typography.labelSmall)
            Spacer(modifier = Modifier.height(10.dp))

            // Main Voice Selector + Audition Button
            Text("Main voice", style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(9.dp))
                            .background(StudioColors.PanelElevated)
                            .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(9.dp))
                            .clickable { mainVoiceMenuOpen = true }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(VoiceStudioCatalog.friendlyVoiceLabel(state.mainVoice), style = MaterialTheme.typography.bodyMedium)
                        Text("▼", color = StudioColors.TextMuted)
                    }
                    DropdownMenu(
                        expanded = mainVoiceMenuOpen,
                        onDismissRequest = { mainVoiceMenuOpen = false },
                        modifier = Modifier.background(StudioColors.PanelElevated)
                    ) {
                        state.baseVoices.forEach { v ->
                            DropdownMenuItem(
                                text = { Text(VoiceStudioCatalog.friendlyVoiceLabel(v), color = StudioColors.TextPrimary) },
                                onClick = {
                                    onCustomMainVoiceChange(v)
                                    mainVoiceMenuOpen = false
                                }
                            )
                        }
                    }
                }
                OutlinedButton(
                    onClick = { onAuditionSingleBaseVoice(state.mainVoice) },
                    enabled = !state.isBusyGenerating,
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Hear main voice")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Blend Voice Selector + Audition Button
            Text("Blend with", style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(9.dp))
                            .background(StudioColors.PanelElevated)
                            .border(1.dp, StudioColors.BorderLine, RoundedCornerShape(9.dp))
                            .clickable { blendVoiceMenuOpen = true }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val label = if (state.blendVoice.isBlank()) "(none)" else VoiceStudioCatalog.friendlyVoiceLabel(state.blendVoice)
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                        Text("▼", color = StudioColors.TextMuted)
                    }
                    DropdownMenu(
                        expanded = blendVoiceMenuOpen,
                        onDismissRequest = { blendVoiceMenuOpen = false },
                        modifier = Modifier.background(StudioColors.PanelElevated)
                    ) {
                        DropdownMenuItem(
                            text = { Text("(none)", color = StudioColors.TextMuted) },
                            onClick = {
                                onCustomBlendVoiceChange("")
                                blendVoiceMenuOpen = false
                            }
                        )
                        state.baseVoices.forEach { v ->
                            DropdownMenuItem(
                                text = { Text(VoiceStudioCatalog.friendlyVoiceLabel(v), color = StudioColors.TextPrimary) },
                                onClick = {
                                    onCustomBlendVoiceChange(v)
                                    blendVoiceMenuOpen = false
                                }
                            )
                        }
                    }
                }
                OutlinedButton(
                    onClick = { onAuditionSingleBaseVoice(state.blendVoice) },
                    enabled = !state.isBusyGenerating && state.blendVoice.isNotBlank(),
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Hear blend voice")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Blend amount", style = MaterialTheme.typography.bodySmall)
                Text("${state.blendPercent}%", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = state.blendPercent.toFloat(),
                onValueChange = { onCustomBlendPctChange(it.toInt()) },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(
                    thumbColor = StudioColors.AccentTeal,
                    activeTrackColor = StudioColors.AccentTeal
                )
            )
        }
    }
}
