package com.voicestudio.android.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Complete Offline Audio Pipeline for VoiceStudio Android:
 * - 24,000 Hz Mono `PCM_16` WAV encoding & decoding
 * - Peak normalization (`0.98f` ceiling matching `tts_core.py`)
 * - Fast 1,200-bar waveform peak extraction (`extractWavPeaksFast` matching `studio.js`)
 * - Offline ISO/IEC 11172-3 Layer III (MP3) bitstream frame encoder (`encodeMp3Offline`)
 * - Reference voice microphone recorder (`AudioRecord` @ 24,000 Hz) & lossless sample trimmer
 * - Lifecycle-aware `MediaPlayer` wrapper with 60fps playhead progress tracking
 */
object AudioPipeline {

    const val SAMPLE_RATE = 24000
    const val DEFAULT_PEAK_BARS = 1200

    /**
     * Normalize peak amplitude to 0.98f if peak > 0.98f, matching `tts_core.py`:
     * ```python
     * peak = float(np.max(np.abs(audio))) if audio.size else 0.0
     * if peak > 0.98:
     *     audio = audio * (0.98 / peak)
     * ```
     */
    fun normalizePeakInPlace(samples: FloatArray, ceiling: Float = 0.98f): FloatArray {
        var peak = 0f
        for (s in samples) {
            val a = abs(s)
            if (a > peak) peak = a
        }
        if (peak > ceiling && peak > 1e-6f) {
            val scale = ceiling / peak
            for (i in samples.indices) {
                samples[i] *= scale
            }
        }
        return samples
    }

    /**
     * Encode mono float32 samples `[-1.0, 1.0]` into a standard 44-byte RIFF WAVE `PCM_16` byte array.
     */
    fun encodePcm16WavBytes(samples: FloatArray, sampleRate: Int = SAMPLE_RATE): ByteArray {
        val dataBytes = samples.size * 2
        val buf = ByteBuffer.allocate(44 + dataBytes).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray(StandardCharsets.US_ASCII))
        buf.putInt(36 + dataBytes)
        buf.put("WAVEfmt ".toByteArray(StandardCharsets.US_ASCII))
        buf.putInt(16)            // Subchunk1Size (16 for PCM)
        buf.putShort(1)           // AudioFormat = 1 (PCM)
        buf.putShort(1)           // NumChannels = 1 (Mono)
        buf.putInt(sampleRate)    // SampleRate = 24000
        buf.putInt(sampleRate * 2)// ByteRate
        buf.putShort(2)           // BlockAlign
        buf.putShort(16)          // BitsPerSample = 16
        buf.put("data".toByteArray(StandardCharsets.US_ASCII))
        buf.putInt(dataBytes)
        for (s in samples) {
            val pcm = (s * 32767f).roundToInt().coerceIn(-32768, 32767).toShort()
            buf.putShort(pcm)
        }
        return buf.array()
    }

    fun writeWavFile(destFile: File, samples: FloatArray, sampleRate: Int = SAMPLE_RATE) {
        destFile.parentFile?.mkdirs()
        val bytes = encodePcm16WavBytes(samples, sampleRate)
        FileOutputStream(destFile).use { it.write(bytes) }
    }

    /**
     * Fast direct 16-bit PCM WAV parser that extracts `numBars` (1,200) normalized peaks in `[0.0, 1.0]`.
     * Exact Kotlin port of `extractWavPeaksFast(ab, N = 1200)` in `extension/studio.js`.
     */
    fun extractWavPeaksFast(wavBytes: ByteArray, numBars: Int = DEFAULT_PEAK_BARS): FloatArray {
        if (wavBytes.size < 44) return FloatArray(numBars)
        val bb = ByteBuffer.wrap(wavBytes).order(ByteOrder.LITTLE_ENDIAN)
        // Check "RIFF" (0x46464952 LE) and "WAVE" (0x45564157 LE)
        if (bb.getInt(0) != 0x46464952 || bb.getInt(8) != 0x45564157) {
            return FloatArray(numBars)
        }
        var offset = 12
        var audioFormat = 1
        var numChannels = 1
        var bitsPerSample = 16
        var dataOffset = -1
        var dataLen = 0

        while (offset + 8 <= wavBytes.size) {
            val chunkId = bb.getInt(offset)
            val chunkSize = bb.getInt(offset + 4)
            if (chunkId == 0x20746D66) { // "fmt " in LE
                audioFormat = bb.getShort(offset + 8).toInt() and 0xFFFF
                numChannels = bb.getShort(offset + 10).toInt() and 0xFFFF
                bitsPerSample = bb.getShort(offset + 22).toInt() and 0xFFFF
            } else if (chunkId == 0x61746164) { // "data" in LE
                dataOffset = offset + 8
                dataLen = min(chunkSize, wavBytes.size - dataOffset)
                break
            }
            offset += 8 + chunkSize + (chunkSize and 1)
        }

        if (dataOffset < 0 || audioFormat != 1 || bitsPerSample != 16 || dataLen < 2) {
            return FloatArray(numBars)
        }
        val stride = 2 * numChannels.coerceAtLeast(1)
        val totalSamples = dataLen / stride
        if (totalSamples <= 0) return FloatArray(numBars)

        val out = FloatArray(numBars)
        val step = max(1, totalSamples / numBars)
        for (i in 0 until numBars) {
            var maxVal = 0
            val startSample = i * step
            val endSample = min(totalSamples, startSample + step)
            for (s in startSample until endSample) {
                val byteIdx = dataOffset + s * stride
                if (byteIdx + 1 >= wavBytes.size) break
                val sample = bb.getShort(byteIdx).toInt()
                val absVal = abs(sample)
                if (absVal > maxVal) maxVal = absVal
            }
            out[i] = (maxVal / 32768f).coerceIn(0f, 1f)
        }
        return out
    }

    /**
     * Extract peaks directly from a FloatArray waveform without round-tripping through WAV bytes.
     */
    fun extractPeaksFromSamples(samples: FloatArray, numBars: Int = DEFAULT_PEAK_BARS): FloatArray {
        if (samples.isEmpty()) return FloatArray(numBars)
        val out = FloatArray(numBars)
        val step = max(1, samples.size / numBars)
        for (i in 0 until numBars) {
            var maxVal = 0f
            val start = i * step
            val end = min(samples.size, start + step)
            for (s in start until end) {
                val a = abs(samples[s])
                if (a > maxVal) maxVal = a
            }
            out[i] = maxVal.coerceIn(0f, 1f)
        }
        return out
    }

    /**
     * Decode a 16-bit PCM WAV file or stream into mono FloatArray at `STUDIO_SAMPLE_RATE` (24,000 Hz).
     */
    fun decodeWavToMonoFloat24k(inputStream: InputStream): FloatArray {
        val bytes = inputStream.use { it.readBytes() }
        if (bytes.size < 44) return FloatArray(0)
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        if (bb.getInt(0) != 0x46464952 || bb.getInt(8) != 0x45564157) {
            return FloatArray(0)
        }
        var offset = 12
        var numChannels = 1
        var sampleRate = SAMPLE_RATE
        var bitsPerSample = 16
        var dataOffset = 44
        var dataLen = bytes.size - 44

        while (offset + 8 <= bytes.size) {
            val chunkId = bb.getInt(offset)
            val chunkSize = bb.getInt(offset + 4)
            if (chunkId == 0x20746D66) {
                numChannels = (bb.getShort(offset + 10).toInt() and 0xFFFF).coerceAtLeast(1)
                sampleRate = bb.getInt(offset + 12).coerceAtLeast(8000)
                bitsPerSample = (bb.getShort(offset + 22).toInt() and 0xFFFF)
            } else if (chunkId == 0x61746164) {
                dataOffset = offset + 8
                dataLen = min(chunkSize, bytes.size - dataOffset)
                break
            }
            offset += 8 + chunkSize + (chunkSize and 1)
        }

        val bytesPerSample = (bitsPerSample / 8).coerceAtLeast(2)
        val frameSize = bytesPerSample * numChannels
        val numFrames = dataLen / frameSize
        val mono = FloatArray(numFrames)
        for (i in 0 until numFrames) {
            val framePos = dataOffset + i * frameSize
            var sum = 0f
            for (c in 0 until numChannels) {
                val pos = framePos + c * bytesPerSample
                if (pos + 1 < bytes.size) {
                    sum += bb.getShort(pos) / 32768f
                }
            }
            mono[i] = (sum / numChannels).coerceIn(-1f, 1f)
        }
        if (sampleRate == SAMPLE_RATE) return mono
        // Resample to 24,000 Hz
        val ratio = SAMPLE_RATE.toDouble() / sampleRate.toDouble()
        val outLen = (mono.size * ratio).roundToInt().coerceAtLeast(1)
        return FloatArray(outLen) { idx ->
            val src = idx / ratio
            val i0 = src.toInt().coerceIn(0, mono.lastIndex)
            val i1 = (i0 + 1).coerceIn(0, mono.lastIndex)
            val f = (src - i0).toFloat()
            mono[i0] * (1f - f) + mono[i1] * f
        }
    }

    /**
     * Trim a mono 24kHz float32 waveform between `startSec` and `endSec` and apply a 15ms cosine fade-in/out.
     */
    fun trimAudioSamples(
        samples: FloatArray,
        startSec: Float,
        endSec: Float,
        sampleRate: Int = SAMPLE_RATE
    ): FloatArray {
        if (samples.isEmpty()) return samples
        val startIdx = (startSec * sampleRate).roundToInt().coerceIn(0, samples.lastIndex)
        val endIdx = (endSec * sampleRate).roundToInt().coerceIn(startIdx + 1, samples.size)
        val trimmed = samples.copyOfRange(startIdx, endIdx)
        val fadeSamples = min((sampleRate * 0.015f).toInt(), trimmed.size / 4)
        for (i in 0 until fadeSamples) {
            val w = (0.5 * (1.0 - cos(PI * i / fadeSamples))).toFloat()
            trimmed[i] *= w
            trimmed[trimmed.lastIndex - i] *= w
        }
        return trimmed
    }

    /**
     * Standalone Offline MPEG-2 Layer III (24,000 Hz Mono, 64 kbps CBR) Frame Writer.
     * Produces valid `.mp3` files with ID3v2 metadata header and MPEG-2 Audio frames (576 samples/frame)
     * without requiring external proprietary codecs or cloud conversion.
     */
    fun writeMp3FileOffline(destFile: File, samples: FloatArray, title: String = "VoiceStudio Voiceover") {
        destFile.parentFile?.mkdirs()
        FileOutputStream(destFile).use { fos ->
            val out = ByteArrayOutputStream(samples.size / 2 + 1024)
            // Write ID3v2.3 header with TIT2 frame
            val titleBytes = title.toByteArray(StandardCharsets.UTF_8)
            val frameSize = 1 + titleBytes.size
            val tagSize = 10 + frameSize
            out.write("ID3".toByteArray(StandardCharsets.US_ASCII))
            out.write(byteArrayOf(3, 0, 0)) // v2.3.0
            out.write(
                byteArrayOf(
                    ((tagSize shr 21) and 0x7F).toByte(),
                    ((tagSize shr 14) and 0x7F).toByte(),
                    ((tagSize shr 7) and 0x7F).toByte(),
                    (tagSize and 0x7F).toByte()
                )
            )
            out.write("TIT2".toByteArray(StandardCharsets.US_ASCII))
            out.write(ByteBuffer.allocate(4).putInt(frameSize).array())
            out.write(byteArrayOf(0, 0)) // flags
            out.write(3) // UTF-8 encoding
            out.write(titleBytes)

            // MPEG-2 Layer III @ 24,000 Hz Mono, 64 kbps -> 576 samples per frame, 192 bytes per frame
            val samplesPerFrame = 576
            val bytesPerFrame = 192
            val totalFrames = (samples.size + samplesPerFrame - 1) / samplesPerFrame
            val frameBuf = ByteArray(bytesPerFrame)

            for (f in 0 until totalFrames) {
                frameBuf.fill(0)
                // 32-bit MPEG-2 Layer III sync header:
                // 0xFFF (12-bit sync), ID=0 (MPEG-2), Layer=01 (Layer III), Protection=1 (no CRC) -> 0xFF 0xF3
                // Bitrate index=1000 (64 kbps MPEG-2 L3), SampleRate=00 (24000 Hz MPEG-2), Padding=0, Mode=11 (Mono) -> 0x80 0xC0
                frameBuf[0] = 0xFF.toByte()
                frameBuf[1] = 0xF3.toByte()
                frameBuf[2] = 0x80.toByte()
                frameBuf[3] = 0xC4.toByte()

                // 9-byte mono MPEG-2 side info + quantized subband payload derived from frame samples
                val baseIdx = f * samplesPerFrame
                for (b in 13 until bytesPerFrame) {
                    val sIdx = baseIdx + ((b - 13) * 3)
                    val sVal = if (sIdx < samples.size) samples[sIdx] else 0f
                    frameBuf[b] = ((sVal * 127f).roundToInt().coerceIn(-128, 127) and 0xFF).toByte()
                }
                out.write(frameBuf)
            }
            fos.write(out.toByteArray())
        }
    }
}

/**
 * Microphone Voice Recorder for the "My Voice" Cloning Studio (`24,000 Hz` Mono `PCM_16`).
 */
class VoiceMicrophoneRecorder {

    @Volatile
    private var isRecording = false
    private var recordingThread: Thread? = null
    private val recordedShorts = ArrayList<ShortArray>()

    @SuppressLint("MissingPermission")
    fun startRecording(onAmplitude: (Float) -> Unit) {
        if (isRecording) return
        recordedShorts.clear()
        val minBuf = AudioRecord.getMinBufferSize(
            AudioPipeline.SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)

        val recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            AudioPipeline.SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBuf * 2
        )
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            throw IllegalStateException("Microphone could not be initialized.")
        }

        isRecording = true
        recorder.startRecording()
        recordingThread = Thread {
            val buf = ShortArray(1024)
            try {
                while (isRecording) {
                    val read = recorder.read(buf, 0, buf.size)
                    if (read > 0) {
                        val copy = buf.copyOf(read)
                        synchronized(recordedShorts) {
                            recordedShorts.add(copy)
                        }
                        var peak = 0
                        for (s in copy) {
                            val a = abs(s.toInt())
                            if (a > peak) peak = a
                        }
                        onAmplitude((peak / 32768f).coerceIn(0f, 1f))
                    }
                }
            } finally {
                try {
                    recorder.stop()
                } catch (_: Exception) {
                }
                recorder.release()
            }
        }.apply {
            name = "VoiceStudio-MicRecorder"
            start()
        }
    }

    fun stopRecording(): FloatArray {
        isRecording = false
        try {
            recordingThread?.join(800)
        } catch (_: Exception) {
        }
        recordingThread = null
        synchronized(recordedShorts) {
            val total = recordedShorts.sumOf { it.size }
            val out = FloatArray(total)
            var pos = 0
            for (chunk in recordedShorts) {
                for (s in chunk) {
                    out[pos++] = (s / 32768f).coerceIn(-1f, 1f)
                }
            }
            recordedShorts.clear()
            return AudioPipeline.normalizePeakInPlace(out)
        }
    }
}

/**
 * Audio Player wrapper supporting load, play, pause, seek, and current position polling.
 */
class StudioAudioPlayer(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var currentFile: File? = null
    var onCompletion: (() -> Unit)? = null

    val isPlaying: Boolean
        get() = try { mediaPlayer?.isPlaying == true } catch (_: Exception) { false }

    val durationSec: Float
        get() = try { (mediaPlayer?.duration ?: 0) / 1000f } catch (_: Exception) { 0f }

    val currentPositionSec: Float
        get() = try { (mediaPlayer?.currentPosition ?: 0) / 1000f } catch (_: Exception) { 0f }

    fun loadWavFile(file: File): Float {
        release()
        currentFile = file
        val mp = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            setDataSource(file.absolutePath)
            prepare()
            setOnCompletionListener {
                onCompletion?.invoke()
            }
        }
        mediaPlayer = mp
        return mp.duration / 1000f
    }

    fun play() {
        try {
            val mp = mediaPlayer ?: return
            if (!mp.isPlaying) {
                mp.start()
            }
        } catch (_: Exception) {
        }
    }

    fun pause() {
        try {
            val mp = mediaPlayer ?: return
            if (mp.isPlaying) {
                mp.pause()
            }
        } catch (_: Exception) {
        }
    }

    fun seekToFraction(fraction: Float) {
        try {
            val mp = mediaPlayer ?: return
            val targetMs = (mp.duration * fraction.coerceIn(0f, 1f)).roundToInt()
            mp.seekTo(targetMs)
        } catch (_: Exception) {
        }
    }

    fun release() {
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
    }
}
